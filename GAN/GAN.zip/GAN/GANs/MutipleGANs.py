# model1 GAN
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models

# 生成正常数据
def generate_normal_data(samples):
    x_normal = np.random.normal(0, 1, samples)
    y_normal = np.random.normal(0, 1, samples)
    normal_data = np.column_stack((x_normal, y_normal))
    return normal_data

# 生成异常数据
def generate_anomaly_data(samples):
    x_anomaly = np.random.uniform(-3, 3, samples)
    y_anomaly = np.random.uniform(-3, 3, samples)
    anomaly_data = np.column_stack((x_anomaly, y_anomaly))
    return anomaly_data

# 定义生成器模型
def build_generator(latent_dim, data_shape):
    model = models.Sequential()
    model.add(layers.Dense(128, input_dim=latent_dim, activation='relu'))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(np.prod(data_shape), activation='sigmoid'))
    model.add(layers.Reshape(data_shape))
    return model

# 定义判别器模型
def build_discriminator(data_shape):
    model = models.Sequential()
    model.add(layers.Flatten(input_shape=data_shape))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))
    return model

# 定义生成对抗网络模型
def build_gan(generator, discriminator):
    discriminator.trainable = False
    model = models.Sequential()
    model.add(generator)
    model.add(discriminator)
    model.compile(loss='binary_crossentropy', optimizer='adam')
    return model

# 定义训练函数
def train_gan(generator, discriminator, gan, data, epochs, batch_size):
    for epoch in range(epochs):
        idx = np.random.randint(0, data.shape[0], batch_size)
        real_data = data[idx]

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        generated_data = generator.predict(noise)

        valid_labels = np.ones((batch_size, 1))
        fake_labels = np.zeros((batch_size, 1))

        d_loss_real = discriminator.train_on_batch(real_data, valid_labels)
        d_loss_fake = discriminator.train_on_batch(generated_data, fake_labels)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        valid_labels = np.ones((batch_size, 1))

        g_loss = gan.train_on_batch(noise, valid_labels)

        # 使用 item() 方法获取标量值
        print(f"Epoch {epoch}/{epochs} [D loss: {d_loss.item()} | D accuracy: {100 * d_loss.item():.2f}%] [G loss: {g_loss}]")

# 生成正常和异常数据
normal_data = generate_normal_data(1000)
anomaly_data = generate_anomaly_data(100)

# 合并数据
data = np.concatenate([normal_data, anomaly_data])

# 定义参数
latent_dim = 10
data_shape = (2,)
epochs = 3000
batch_size = 32

# 创建生成器、判别器和生成对抗网络
generator = build_generator(latent_dim, data_shape)
discriminator = build_discriminator(data_shape)
gan = build_gan(generator, discriminator)

# 编译生成器和判别器
generator.compile(loss='binary_crossentropy', optimizer='adam')
discriminator.compile(loss='binary_crossentropy', optimizer='adam')

# 训练生成对抗网络
train_gan(generator, discriminator, gan, data, epochs, batch_size)

# 生成一些样本并可视化
generated_samples = generator.predict(np.random.normal(0, 1, (100, latent_dim)))

plt.scatter(normal_data[:, 0], normal_data[:, 1], label='Normal Data')
plt.scatter(anomaly_data[:, 0], anomaly_data[:, 1], label='Anomaly Data')
plt.legend()

# 调整子图布局
plt.tight_layout()

# 将图表保存为 SVG 文件
plt.savefig('GAN_Aviation_anomaly_data_detection_model1.svg', format='svg', bbox_inches='tight')

plt.show()

# model2 EGBAD EFFICIENT GAN-BASED ANOMALY DETECTION(基于GAN的高效异常检测)，AnoGAN的改进版EGBAD
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models

# 定义生成器模型
def build_generator(latent_dim, data_shape):
    model = models.Sequential()
    model.add(layers.Dense(128, input_dim=latent_dim, activation='relu'))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(np.prod(data_shape), activation='sigmoid'))
    model.add(layers.Reshape(data_shape))
    return model

# 定义判别器模型
def build_discriminator(data_shape):
    model = models.Sequential()
    model.add(layers.Flatten(input_shape=data_shape))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))
    return model

# 定义 EGBAD 生成对抗网络模型
def build_egbad(generator, discriminator):
    discriminator.trainable = False
    model = models.Sequential()
    model.add(generator)
    model.add(discriminator)
    model.compile(loss='binary_crossentropy', optimizer='adam')
    return model

# 定义训练函数
def train_egbad(generator, discriminator, egbad, data, epochs, batch_size):
    d_losses = []
    g_losses = []

    for epoch in range(epochs):
        idx = np.random.randint(0, data.shape[0], batch_size)
        real_data = data[idx]

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        generated_data = generator.predict(noise)

        valid_labels = np.ones((batch_size, 1))
        fake_labels = np.zeros((batch_size, 1))

        d_loss_real = discriminator.train_on_batch(real_data, valid_labels)
        d_loss_fake = discriminator.train_on_batch(generated_data, fake_labels)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        valid_labels = np.ones((batch_size, 1))

        g_loss = egbad.train_on_batch(noise, valid_labels)

        # 适应不同版本的 Keras 返回值
        d_loss_scalar = d_loss if np.isscalar(d_loss) else d_loss[0]
        d_acc_scalar = d_loss if np.isscalar(d_loss) else d_loss[1]

        d_losses.append(d_loss_scalar)
        g_losses.append(g_loss)

        # 使用 item() 方法获取标量值
        print(
            f"Epoch {epoch}/{epochs} [D loss: {float(d_loss_scalar):.4f} | D accuracy: {100 * float(d_acc_scalar):.2f}%] [G loss: {float(g_loss):.4f}]")

    return d_losses, g_losses

# 定义参数
latent_dim = 10
data_shape = (2,)
epochs = 3000
batch_size = 32

# 创建生成器、判别器和 EGBAD 生成对抗网络
generator = build_generator(latent_dim, data_shape)
discriminator = build_discriminator(data_shape)
egbad = build_egbad(generator, discriminator)

# 编译生成器和判别器
generator.compile(loss='binary_crossentropy', optimizer='adam')
discriminator.compile(loss='binary_crossentropy', optimizer='adam')

# 生成正常和异常数据
real_data = np.concatenate([np.random.normal(0, 1, (1000, 2)), np.random.normal(0, 1, (100, 2))])
fake_data = generator.predict(np.random.normal(0, 2, (100, latent_dim)))

# 合并数据
data = np.concatenate([real_data, fake_data])

# 训练 EGBAD 生成对抗网络
d_losses, g_losses = train_egbad(generator, discriminator, egbad, data, epochs, batch_size)

# 绘制损失曲线
plt.plot(range(epochs), d_losses, label='Discriminator Loss')
plt.plot(range(epochs), g_losses, label='Generator Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

# 调整子图布局
plt.tight_layout()

# 将图表保存为 SVG 文件
plt.savefig('GAN_Aviation_anomaly_data_detection_model2_1.svg', format='svg', bbox_inches='tight')

plt.show()

# 生成一些样本并可视化
generated_samples = generator.predict(np.random.normal(0, 1, (100, latent_dim)))

plt.scatter(real_data[:, 0], real_data[:, 1], label='Real Data')
plt.scatter(fake_data[:, 0], fake_data[:, 1], label='Generated Data', marker='p')
plt.legend()

# 调整子图布局
plt.tight_layout()

# 将图表保存为 SVG 文件
plt.savefig('GAN_Aviation_anomaly_data_detection_model2_2.svg', format='svg', bbox_inches='tight')

plt.show()

# model3_1 WGAN Wasserstein Generative Adversarial Networks，GAN的改进版WGAN
import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
import matplotlib.pyplot as plt

# Set random seed for reproducibility
tf.random.set_seed(42)
np.random.seed(42)


# Define the generator model
def build_generator(latent_dim):
    model = tf.keras.Sequential()
    model.add(layers.Dense(128, input_dim=latent_dim, activation='relu'))
    model.add(layers.Dense(2, activation='tanh'))  # Output layer with 2 nodes for 2D data
    return model


# Define the discriminator model
def build_discriminator():
    model = tf.keras.Sequential()
    model.add(layers.Dense(128, input_dim=2, activation='relu'))
    model.add(layers.Dense(1, activation=None))  # No activation in the last layer for WGAN
    return model


# Define the Wasserstein loss
def wasserstein_loss(y_true, y_pred):
    return tf.reduce_mean(y_true * y_pred)


# Define the training step for the discriminator
def train_discriminator(discriminator, real_data, fake_data, optimizer):
    with tf.GradientTape() as tape:
        real_output = discriminator(real_data, training=True)
        fake_output = discriminator(fake_data, training=True)
        d_loss = wasserstein_loss(real_output, fake_output)

    gradients = tape.gradient(d_loss, discriminator.trainable_variables)
    optimizer.apply_gradients(zip(gradients, discriminator.trainable_variables))

    # Clip the weights of the discriminator
    for w in discriminator.trainable_variables:
        w.assign(tf.clip_by_value(w, -0.01, 0.01))

    return d_loss


# Define the training step for the generator
def train_generator(generator, discriminator, latent_dim, batch_size, optimizer):
    noise = tf.random.normal((batch_size, latent_dim))

    with tf.GradientTape() as tape:
        generated_data = generator(noise, training=True)
        fake_output = discriminator(generated_data, training=True)
        g_loss = -tf.reduce_mean(fake_output)

    gradients = tape.gradient(g_loss, generator.trainable_variables)
    optimizer.apply_gradients(zip(gradients, generator.trainable_variables))

    return g_loss


# Generate random real data for the example
real_data = np.random.randn(100, 2)

# Set hyperparameters
latent_dim = 30 # 潜在空间的维度，它是生成器模型输入的维度,足够大以捕捉数据的关键特征，但也不能太大，以避免引入过多噪音或增加计算成本。
epochs = 800 # 训练的轮数，即整个训练数据集被完整遍历的次数。增加 epoch 可以提高模型的训练效果，但如果太大，可能导致过拟合。
batch_size = 32 # 每个训练步中使用的样本数。使用小批量样本进行训练可以加速模型训练，并降低内存需求。较大的 batch_size 可以提高训练速度，但可能使模型更难收敛。
lr = 0.00001  # 学习率，用于控制每次参数更新的步长。学习率过大可能导致模型不稳定，学习率过小可能导致训练过慢或者陷入局部最小值。

# Build and compile the models
generator = build_generator(latent_dim)
discriminator = build_discriminator()
generator_optimizer = tf.keras.optimizers.RMSprop(lr)
discriminator_optimizer = tf.keras.optimizers.RMSprop(lr)

# Training loop
d_losses, g_losses = [], []
for epoch in range(epochs):
    for _ in range(len(real_data) // batch_size):
        # Train discriminator
        batch_real_data = real_data[np.random.choice(len(real_data), batch_size, replace=False)]
        noise = tf.random.normal((batch_size, latent_dim))
        batch_fake_data = generator(noise, training=True)
        d_loss = train_discriminator(discriminator, batch_real_data, batch_fake_data, discriminator_optimizer)

    # Train generator
    noise = tf.random.normal((len(real_data), latent_dim))
    g_loss = train_generator(generator, discriminator, latent_dim, len(real_data), generator_optimizer)

    d_losses.append(d_loss.numpy())
    g_losses.append(g_loss.numpy())

    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Discriminator Loss: {d_loss.numpy()}, Generator Loss: {g_loss.numpy()}")

# Generate fake data for plotting
noise = tf.random.normal((len(real_data), latent_dim))
fake_data = generator(noise, training=False).numpy()

# Plot generated and real data
plt.scatter(real_data[:, 0], real_data[:, 1], label='Real Data')
plt.scatter(fake_data[:, 0], fake_data[:, 1], label='Generated Data', marker='p')
plt.legend()
plt.tight_layout()
plt.savefig('WGAN_Aviation_anomaly_data_detection_model3_1.svg', format='svg', bbox_inches='tight')
plt.show()

# Plot loss curves
plt.plot(range(epochs), d_losses, label='Discriminator Loss')
plt.plot(range(epochs), g_losses, label='Generator Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.tight_layout()
plt.savefig('WGAN_Aviation_anomaly_data_detection_model3_2.svg', format='svg', bbox_inches='tight')
plt.show()

# model3_2
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras import layers, models, optimizers
from tensorflow.keras import backend as K

# Define Wasserstein loss
def wasserstein_loss(y_true, y_pred):
    return -K.mean(y_true * y_pred)

# Define generator model
def build_generator(latent_dim, data_shape):
    model = models.Sequential()
    model.add(layers.Dense(128, input_dim=latent_dim, activation='relu'))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(np.prod(data_shape)))
    model.add(layers.Reshape(data_shape))
    return model

# Define discriminator model
def build_discriminator(data_shape):
    model = models.Sequential()
    model.add(layers.Flatten(input_shape=data_shape))
    model.add(layers.Dense(256, activation='relu'))
    model.add(layers.Dense(1))
    model.compile(loss=wasserstein_loss, optimizer=optimizers.RMSprop(learning_rate=0.00001))
    return model

# Define WGAN model
def build_wgan(generator, discriminator):
    discriminator.trainable = False
    model = models.Sequential()
    model.add(generator)
    model.add(discriminator)
    model.compile(loss=wasserstein_loss, optimizer=optimizers.RMSprop(learning_rate=0.00001))
    return model

# Define training function
def train_wgan(generator, discriminator, wgan, data, epochs, batch_size, latent_dim):
    d_losses = []
    g_losses = []

    for epoch in range(epochs):
        idx = np.random.randint(0, data.shape[0], batch_size)
        real_data = data[idx]

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        generated_data = generator.predict(noise)

        real_labels = -np.ones((batch_size, 1))
        fake_labels = np.ones((batch_size, 1))

        d_loss_real = discriminator.train_on_batch(real_data, real_labels)
        d_loss_fake = discriminator.train_on_batch(generated_data, fake_labels)
        d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

        noise = np.random.normal(0, 1, (batch_size, latent_dim))
        g_loss = wgan.train_on_batch(noise, real_labels)

        d_losses.append(d_loss)
        g_losses.append(g_loss)

        print(f"Epoch {epoch}/{epochs} [D loss: {d_loss:.4f}] [G loss: {g_loss:.4f}]")

    return d_losses, g_losses

# Set parameters
latent_dim = 30
data_shape = (2,)
epochs = 800
batch_size = 16

# Create generator, discriminator, and WGAN models
generator = build_generator(latent_dim, data_shape)
discriminator = build_discriminator(data_shape)
wgan = build_wgan(generator, discriminator)

# Generate real and fake data
real_data = np.concatenate([np.random.normal(0, 1, (1000, 2)), np.random.normal(0, 1, (100, 2))])
fake_data = generator.predict(np.random.normal(0, 2, (100, latent_dim)))

# Combine data
data = np.concatenate([real_data, fake_data])

# Train WGAN
d_losses, g_losses = train_wgan(generator, discriminator, wgan, data, epochs, batch_size, latent_dim)

# Save generated and real data plot
plt.scatter(real_data[:, 0], real_data[:, 1], label='Real Data')
plt.scatter(fake_data[:, 0], fake_data[:, 1], label='Generated Data', marker='p')
plt.legend()
plt.tight_layout()
plt.savefig('WGAN_Aviation_anomaly_data_detection_model3_3.svg', format='svg', bbox_inches='tight')
plt.show()

# Plot loss curves
plt.plot(range(epochs), d_losses, label='Discriminator Loss')
plt.plot(range(epochs), g_losses, label='Generator Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.tight_layout()
plt.savefig('WGAN_Aviation_anomaly_data_detection_model3_4.svg', format='svg', bbox_inches='tight')
plt.show()
