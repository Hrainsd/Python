import os
import pandas as pd

# Paths for input and output folders
input_folder = r"D:\大学\本科\星空地ADS-B\论文\0713\0713"
output_folder = r"D:\大学\本科\星空地ADS-B\论文\0713\0713-csv"

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Loop over each .txt file in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith(".txt"):
        txt_path = os.path.join(input_folder, filename)

        # Read each line and parse the data
        data = []
        with open(txt_path, 'r', encoding='utf-8') as file:
            for line in file:
                # Replace the last colon with a comma
                line = line.rsplit(":", 1)  # Split only at the last occurrence
                if len(line) == 2:
                    timestamp = line[0] + ','  # Keep the timestamp and add a comma
                    rest_of_line = line[1]  # Remaining data
                    # Combine timestamp with the rest of the line
                    full_line = timestamp + rest_of_line.strip()
                    # Split by comma to extract each value
                    row = full_line.split(',')
                    data.append(row)

        # Convert the list of rows into a DataFrame
        df = pd.DataFrame(data, columns=[
            'Timestamp', 'ID1', 'ID2', 'Longitude', 'Latitude', 'Altitude', 'Speed', 'Direction', 'Unknown', 'Vertical Rate'
        ])

        # Save DataFrame to CSV with the same filename as the original txt
        csv_path = os.path.join(output_folder, filename.replace(".txt", ".csv"))
        df.to_csv(csv_path, index=False, encoding='utf-8')

print("Conversion complete!")