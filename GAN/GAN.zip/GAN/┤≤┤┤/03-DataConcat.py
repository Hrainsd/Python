import pandas as pd

# 定义文件路径
file_path_1 = r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\001.csv'
file_path_2 = r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\002.csv'
output_file_path = r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\006.csv'

# 读取1.1.csv文件并添加Label列，正常数据值全为0
df_1 = pd.read_csv(file_path_1)
df_1['Label'] = 0

# 读取2.csv文件并添加Label列，异常数据值全为1
df_2 = pd.read_csv(file_path_2)
df_2['Label'] = 1

# 合并两个DataFrame
merged_df = pd.concat([df_1, df_2])

# 将合并后的DataFrame保存为新的CSV文件
merged_df.to_csv(output_file_path, index=False)

print("已合并并保存到新的CSV文件中。")
