import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, precision_recall_curve
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
import time

# 设置字体
plt.rcParams['font.family'] = 'Microsoft YaHei'
# 设置字体大小
plt.rcParams['font.size'] = 16

# 加载数据
data = pd.read_csv(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\006.csv')

# 划分特征和标签
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 数据标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 定义模型评估指标函数
def evaluate_model(y_true, y_pred, y_pred_prob):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    precision_curve, recall_curve, _ = precision_recall_curve(y_true, y_pred_prob)
    pr_auc = auc(recall_curve, precision_curve)
    return accuracy, precision, recall, f1, roc_auc, pr_auc, fpr, tpr, recall_curve, precision_curve

# 用于保存评估指标的字典
metrics_data = {
    'Model': [],
    '准确率': [],
    '精确率': [],
    '召回率': [],
    'F1分数': [],
    'ROC AUC': [],
    'PR AUC': [],
    '总检测耗时 (s)': [],
    '异常检测次数': [],
    '检测耗时 (每次) (ms)': [],
    'fpr': [],
    'tpr': [],
    'recall_curve': [],
    'precision_curve': []
}

# 训练和评估模型的函数
def train_and_evaluate_model(model, model_name):
    start_time = time.time()  # 开始时间
    model.fit(X_train_scaled, y_train)  # 训练模型
    predictions = model.predict(X_test_scaled)  # 预测
    end_time = time.time()  # 结束时间

    total_time = end_time - start_time  # 总耗时
    detection_count = len(X_test_scaled)  # 检测次数
    time_per_detection = total_time / detection_count * 1000  # 转换为每次检测的毫秒数

    pred_prob = model.predict_proba(X_test_scaled)[:, 1]  # 获取预测概率
    accuracy, precision, recall, f1, roc_auc, pr_auc, fpr, tpr, recall_curve, precision_curve = evaluate_model(
        y_test, predictions, pred_prob)

    # 保存评估结果
    metrics_data['Model'].append(model_name)
    metrics_data['准确率'].append(accuracy)
    metrics_data['精确率'].append(precision)
    metrics_data['召回率'].append(recall)
    metrics_data['F1分数'].append(f1)
    metrics_data['ROC AUC'].append(roc_auc)
    metrics_data['PR AUC'].append(pr_auc)
    metrics_data['总检测耗时 (s)'].append(total_time)
    metrics_data['异常检测次数'].append(detection_count)
    metrics_data['检测耗时 (每次) (ms)'].append(time_per_detection)
    metrics_data['fpr'].append(fpr)  # 保存假阳性率
    metrics_data['tpr'].append(tpr)  # 保存真阳性率
    metrics_data['recall_curve'].append(recall_curve)  # 保存召回率
    metrics_data['precision_curve'].append(precision_curve)  # 保存精确率

    print(f"{model_name}评估指标：准确率 {accuracy:.4f}, 精确率 {precision:.4f}, 召回率 {recall:.4f}, "
          f"F1 {f1:.4f}, ROC AUC {roc_auc:.4f}, PR AUC {pr_auc:.4f}, 总检测耗时 {total_time:.4f}s, "
          f"异常检测次数 {detection_count}, 检测耗时(每次) {time_per_detection:.4f}ms")

# XGBoost模型
xgb_model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
train_and_evaluate_model(xgb_model, '极限梯度提升')

# 朴素贝叶斯模型
gnb_model = GaussianNB()
train_and_evaluate_model(gnb_model, '朴素贝叶斯')

# 逻辑回归模型
logreg_model = LogisticRegression()  # 增加最大迭代次数以确保收敛
train_and_evaluate_model(logreg_model, '逻辑回归')

# 多层感知机模型
mlp_model = MLPClassifier()  # 增加最大迭代次数以确保收敛
train_and_evaluate_model(mlp_model, '多层感知机')

# 转换为DataFrame并保存为CSV文件
metrics_df = pd.DataFrame(metrics_data)
metrics_df.to_csv(
    r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\007-模型评估结果.csv', index=False)

print("所有模型的评估结果已保存到CSV文件中。")

# 绘制ROC曲线
plt.figure(figsize=(10, 6))

for i in range(len(metrics_data['Model'])):
    plt.plot(metrics_data['fpr'][i], metrics_data['tpr'][i], label='{} (AUC = {:.4f})'.format(
        metrics_data['Model'][i], metrics_data['ROC AUC'][i]), lw=2)

plt.xlabel('假阳性率')
plt.ylabel('真阳性率')
plt.legend(loc="lower right", frameon=False)
plt.savefig(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\008-ROC.svg', format='svg', bbox_inches='tight')
plt.show()

# 绘制PRC曲线
plt.figure(figsize=(10, 6))

for i in range(len(metrics_data['Model'])):
    recall_curve = metrics_data['recall_curve'][i]  # 使用召回率
    precision_curve = metrics_data['precision_curve'][i]  # 使用精确率
    plt.plot(recall_curve, precision_curve, label='{} (AUC = {:.4f})'.format(
        metrics_data['Model'][i], metrics_data['PR AUC'][i]), lw=2)

plt.xlabel('召回率')
plt.ylabel('精确率')
plt.legend(loc="lower right", frameon=False)
plt.savefig(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\009-PRC.svg', format='svg', bbox_inches='tight')
plt.show()
