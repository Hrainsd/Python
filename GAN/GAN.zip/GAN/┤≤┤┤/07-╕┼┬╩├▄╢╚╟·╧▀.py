import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 设置字体
plt.rcParams['font.family'] = 'Microsoft YaHei'
# 设置字体大小
plt.rcParams['font.size'] = 16

# 文件路径
file1 = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\001.csv"
file2 = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\大创\002.csv"

# 读取CSV文件
df1 = pd.read_csv(file1)
df2 = pd.read_csv(file2)

# 从CSV文件中提取特征列名，假设前5列是我们需要的特征
features = df1.columns[:5].tolist()  # 提取前5列列名
true_features = ['经度', '维度', '高度', '速度', '航向']  # 中文特征名

# 初始化图形名称的计数器
start_index = 17  # 从11开始

# 为每个文件和每个特征绘制密度曲线，并保存为SVG文件
for i, (feature, true_feature) in enumerate(zip(features, true_features)):
    plt.figure(figsize=(12, 6))

    # 第一个文件的密度曲线
    plt.subplot(1, 2, 1)
    sns.kdeplot(df1[feature], shade=True, color='blue', bw_adjust=0.2)  # 设置带宽调整曲线平滑程度bw_adjust
    plt.title('真实数据')
    plt.xlabel(true_feature)
    plt.ylabel('密度')

    # 第二个文件的密度曲线
    plt.subplot(1, 2, 2)
    sns.kdeplot(df2[feature], shade=True, color='green', bw_adjust=0.2)  # 设置带宽调整曲线平滑程度bw_adjust
    plt.title('生成数据')
    plt.xlabel(true_feature)
    plt.ylabel('密度')

    # 调整布局
    plt.tight_layout()

    # 保存图形为SVG文件，名称格式化为i + start_index
    svg_filename = f"{start_index + i:03d}_{true_feature}概率密度图.svg"
    plt.savefig(svg_filename, format='svg')

    # 显示图形
    plt.show()
