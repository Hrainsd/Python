import pandas as pd

# 加载数据集并提取所需的列
file_path = r"D:\大学\本科\星空地ADS-B\论文\0713\0713-csv\20190712-231637.csv"
df = pd.read_csv(file_path, usecols=["Longitude", "Latitude", "Altitude", "Speed", "Direction"])

# 删除包含缺失值的行
df = df.dropna()

# 将处理后的数据保存到新的CSV文件
output_file_path = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\低空\000.csv"
df.to_csv(output_file_path, index=False)
print("已提取所需列，删除空值行，并保存到新的CSV文件中。")

# 加载刚才保存的CSV文件，并过滤高度小于3000的行
df_filtered = pd.read_csv(output_file_path)
df_filtered = df_filtered[df_filtered["Altitude"] <= 3000]

# 将过滤后的数据保存到另一个CSV文件
filtered_output_file_path = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\低空\001.csv"
df_filtered.to_csv(filtered_output_file_path, index=False)
print("已将高度在3000以内的数据保存到001.csv。")
