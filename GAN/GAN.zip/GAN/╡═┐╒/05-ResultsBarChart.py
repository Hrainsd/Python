import pandas as pd
import matplotlib.pyplot as plt

# 加载评估结果文件
metrics_df = pd.read_csv(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\低空\007-模型评估结果.csv')

# 设置字体
plt.rcParams['font.family'] = 'Microsoft YaHei'
# 设置字体大小
plt.rcParams['font.size'] = 16

# 获取模型名称
models = metrics_df['Model'].tolist()

# 获取指标值
values = {
    model: [
        metrics_df.loc[metrics_df['Model'] == model, '准确率'].values[0],
        metrics_df.loc[metrics_df['Model'] == model, '精确率'].values[0],
        metrics_df.loc[metrics_df['Model'] == model, '召回率'].values[0],
        metrics_df.loc[metrics_df['Model'] == model, 'F1分数'].values[0],
        metrics_df.loc[metrics_df['Model'] == model, 'ROC AUC'].values[0],
        metrics_df.loc[metrics_df['Model'] == model, 'PR AUC'].values[0]
    ] for model in models
}

metrics = ['准确率', '精确率', '召回率', 'F1分数', 'ROC AUC', 'PR AUC']

fig, ax = plt.subplots(figsize=(12, 8))
width = 0.15  # 设置柱形图宽度
x = range(len(metrics))

colors = ['#E06D83', '#FFC947', '#7ED957', '#B292CA']  # 设置颜色
patterns = ['/', '.', '\\', 'o']  # 设置柱形图填充形状

# p*x为两个指标之间的宽度，i*(width)是两个模型之间的宽度
for i, model in enumerate(models):
    ax.bar([p + i * (width) for p in x], values[model], width=width, label=model, color=colors[i], hatch=patterns[i])
    # 在柱形上显示值
    for j, value in enumerate(values[model]):
        ax.text(j + i * (width), value + 0.01, f'{value:.2f}', ha='center', fontsize=10)

# 调整柱形图位置
ax.set_xticks([p + 1.5 * width for p in x])
ax.set_xticklabels(metrics)
ax.set_xlabel('评估指标')
ax.set_ylabel('指标值')
ax.legend(frameon=False, bbox_to_anchor=(1, 1))
plt.savefig(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\低空\010-BarChart.svg', format='svg', bbox_inches='tight')
plt.show()

detection_times = metrics_df['检测耗时 (每次) (ms)'].tolist()

# 定义颜色列表
colors = ['#E06D83', '#FFC947', '#7ED957', '#D45D7D', '#B292CA', '#4C92A3']  # 可以根据需要添加更多颜色

# 确保颜色列表与模型数量匹配
if len(colors) < len(models):
    raise ValueError(f"颜色数量 {len(colors)} 小于模型数量 {len(models)}。请添加更多颜色。")

# 绘制柱形图
plt.figure(figsize=(10, 6))
bars = plt.bar(models, detection_times, color=colors[:len(models)], alpha=0.7)

# 在每个柱子上显示具体数值
for bar in bars:
    yval = bar.get_height()  # 获取柱子的高度
    plt.text(bar.get_x() + bar.get_width()/2, yval, f'{yval:.4f}', ha='center', va='bottom', fontsize=10)

# 设置坐标轴标签和标题
plt.xlabel('模型')
plt.ylabel('检测耗时 (每次) (ms)')
plt.title('模型检测耗时柱形图')
plt.xticks(rotation=0)  # 不旋转x轴标签
plt.grid(False)

# 保存并显示图形
plt.tight_layout()
plt.savefig(r'C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\GAN\低空\011-检测耗时柱形图.svg', format='svg', bbox_inches='tight')
plt.show()