import matplotlib.pyplot as plt

# 设置字体
plt.rcParams['font.family'] = 'Times New Roman'
# 设置字体大小
plt.rcParams['font.size'] = 16

models = ['XGBoost', 'KNN', 'DT', 'NB', 'LR']
metrics = ['Accuracy', 'Precision', 'Recall', 'F1', 'ROC AUC', 'PRC AUC']

values = {
    'Cluster 1': {
        'XGBoost': [1.0000, 1.0000, 0.9976, 0.9988, 1.0000, 1.0000],
        'KNN': [0.9981, 0.9990, 0.9900, 0.9945, 0.9986, 0.9988],
        'DT': [0.9984, 0.9967, 0.9938, 0.9952, 0.9966, 0.9958],
        'NB': [0.9842, 0.9533, 0.9542, 0.9538, 0.9983, 0.9927],
        'LR': [0.8971, 0.7216, 0.6473, 0.6824, 0.9479, 0.6688]
    },
    'Cluster 2': {
        'XGBoost': [0.9981, 0.9947, 0.9936, 0.9941, 1.0000, 0.9998],
        'KNN': [0.9941, 0.9973, 0.9665, 0.9816, 0.9934, 0.9943],
        'DT': [0.9958, 0.9917, 0.9827, 0.9872, 0.9905, 0.9886],
        'NB': [0.9222, 0.7134, 0.8774, 0.7869, 0.9699, 0.8880],
        'LR': [0.8317, 0.3992, 0.0553, 0.0972, 0.7554, 0.3360]
    },
    'Cluster 3': {
        'XGBoost': [0.9985, 0.9996, 0.9916, 0.9956, 0.9999, 0.9998],
        'KNN': [0.9971, 0.9993, 0.9832, 0.9912, 0.9969, 0.9974],
        'DT': [0.9973, 0.9964, 0.9872, 0.9918, 0.9932, 0.9929],
        'NB': [0.9675, 0.9095, 0.8943, 0.9018, 0.9891, 0.9609],
        'LR': [0.8038, 0.2059, 0.0616, 0.0948, 0.8564, 0.3932]
    },
    'Cluster 4': {
        'XGBoost': [0.9994, 1.0000, 0.9964, 0.9982, 1.0000, 1.0000],
        'KNN': [0.9982, 1.0000, 0.9888, 0.9944, 0.9982, 0.9985],
        'DT': [0.9984, 0.9988, 0.9912, 0.9950, 0.9955, 0.9957],
        'NB': [0.9734, 0.9323, 0.9036, 0.9177, 0.9918, 0.9731],
        'LR': [0.9500, 0.8870, 0.7976, 0.8399, 0.9716, 0.9214]
    }
}

width = 0.15  # 设置柱形图宽度
x = range(len(metrics))
colors = ['#FED7AA', '#FFC1E3', '#A4D4AE', '#EAD9D5', '#B0E0E6']  # 设置颜色
patterns = ['/', '.', '\\', 'o', 'x']  # 设置柱形图填充形状

fig, axes = plt.subplots(2, 2, figsize=(15, 10))

# p*x为两个指标之间的宽度，i*(width+x)是两个模型之间的宽度
for idx, (cluster, cluster_data) in enumerate(values.items()):
    row = idx // 2
    col = idx % 2
    ax = axes[row, col]
    for i, model in enumerate(models):
        bar_positions = [p + i * (width + 0.05) for p in x]
        ax.bar(bar_positions, cluster_data[model], width=width, label=model, color=colors[i], hatch=patterns[i])

    # 调整柱形图位置
    ax.set_xticks([p + 2.5 * width for p in x])
    ax.set_xticklabels(metrics, rotation=45)  # 旋转x轴标签
    ax.set_ylabel('Values')
    ax.set_title(cluster)

# 添加legend到(0×1)
axes[0, 1].legend(loc="lower right", frameon=False, markerscale=10, bbox_to_anchor=(1.32, 0.5))
plt.subplots_adjust(hspace=0.4)  # 增加上下行之间的距离
plt.savefig(f'Cluster_Barcharts.svg', format='svg')
plt.show()

# Cluster 1: 极致梯度提升树评估指标：准确率 0.9996, 精确率 1.0000, 召回率 0.9976, F1 0.9988, ROC AUC 1.0000, 总检测耗时 0.1700s, 异常检测次数 12287, 检测耗时(每次) 0.0138ms
# Cluster 1: K最近邻评估指标：准确率 0.9981, 精确率 0.9990, 召回率 0.9900, F1 0.9945, ROC AUC 0.9986, 总检测耗时 0.2417s, 异常检测次数 12287, 检测耗时(每次) 0.0197ms
# Cluster 1: 决策树评估指标：准确率 0.9984, 精确率 0.9967, 召回率 0.9938, F1 0.9952, ROC AUC 0.9966, 总检测耗时 0.1160s, 异常检测次数 12287, 检测耗时(每次) 0.0094ms
# Cluster 1: 朴素贝叶斯评估指标：准确率 0.9842, 精确率 0.9533, 召回率 0.9542, F1 0.9538, ROC AUC 0.9983, 总检测耗时 0.0081s, 异常检测次数 12287, 检测耗时(每次) 0.0007ms
# Cluster 1: 逻辑回归评估指标：准确率 0.8971, 精确率 0.7216, 召回率 0.6473, F1 0.6824, ROC AUC 0.9479, 总检测耗时 0.0530s, 异常检测次数 12287, 检测耗时(每次) 0.0043ms
# Cluster 1: XGBoost PRC AUC: 1.0000
# Cluster 1: KNN PRC AUC: 0.9988
# Cluster 1: Decision Tree PRC AUC: 0.9958
# Cluster 1: GaussianNB PRC AUC: 0.9927
# Cluster 1: Logistic Regression PRC AUC: 0.6688
# Cluster 2: 极致梯度提升树评估指标：准确率 0.9981, 精确率 0.9947, 召回率 0.9936, F1 0.9941, ROC AUC 1.0000, 总检测耗时 0.2194s, 异常检测次数 22962, 检测耗时(每次) 0.0096ms
# Cluster 2: K最近邻评估指标：准确率 0.9941, 精确率 0.9973, 召回率 0.9665, F1 0.9816, ROC AUC 0.9934, 总检测耗时 0.4386s, 异常检测次数 22962, 检测耗时(每次) 0.0191ms
# Cluster 2: 决策树评估指标：准确率 0.9958, 精确率 0.9917, 召回率 0.9827, F1 0.9872, ROC AUC 0.9905, 总检测耗时 0.2653s, 异常检测次数 22962, 检测耗时(每次) 0.0116ms
# Cluster 2: 朴素贝叶斯评估指标：准确率 0.9222, 精确率 0.7134, 召回率 0.8774, F1 0.7869, ROC AUC 0.9699, 总检测耗时 0.0120s, 异常检测次数 22962, 检测耗时(每次) 0.0005ms
# Cluster 2: 逻辑回归评估指标：准确率 0.8317, 精确率 0.3992, 召回率 0.0553, F1 0.0972, ROC AUC 0.7554, 总检测耗时 0.0460s, 异常检测次数 22962, 检测耗时(每次) 0.0020ms
# Cluster 2: XGBoost PRC AUC: 0.9998
# Cluster 2: KNN PRC AUC: 0.9943
# Cluster 2: Decision Tree PRC AUC: 0.9886
# Cluster 2: GaussianNB PRC AUC: 0.8880
# Cluster 2: Logistic Regression PRC AUC: 0.3360
# Cluster 3: 极致梯度提升树评估指标：准确率 0.9985, 精确率 0.9996, 召回率 0.9916, F1 0.9956, ROC AUC 0.9999, 总检测耗时 0.2471s, 异常检测次数 27149, 检测耗时(每次) 0.0091ms
# Cluster 3: K最近邻评估指标：准确率 0.9971, 精确率 0.9993, 召回率 0.9832, F1 0.9912, ROC AUC 0.9969, 总检测耗时 0.5450s, 异常检测次数 27149, 检测耗时(每次) 0.0201ms
# Cluster 3: 决策树评估指标：准确率 0.9973, 精确率 0.9964, 召回率 0.9872, F1 0.9918, ROC AUC 0.9932, 总检测耗时 0.2767s, 异常检测次数 27149, 检测耗时(每次) 0.0102ms
# Cluster 3: 朴素贝叶斯评估指标：准确率 0.9675, 精确率 0.9095, 召回率 0.8943, F1 0.9018, ROC AUC 0.9891, 总检测耗时 0.0151s, 异常检测次数 27149, 检测耗时(每次) 0.0006ms
# Cluster 3: 逻辑回归评估指标：准确率 0.8038, 精确率 0.2059, 召回率 0.0616, F1 0.0948, ROC AUC 0.8564, 总检测耗时 0.0548s, 异常检测次数 27149, 检测耗时(每次) 0.0020ms
# Cluster 3: XGBoost PRC AUC: 0.9998
# Cluster 3: KNN PRC AUC: 0.9974
# Cluster 3: Decision Tree PRC AUC: 0.9929
# Cluster 3: GaussianNB PRC AUC: 0.9609
# Cluster 3: Logistic Regression PRC AUC: 0.3932
# Cluster 4: 极致梯度提升树评估指标：准确率 0.9994, 精确率 1.0000, 召回率 0.9964, F1 0.9982, ROC AUC 1.0000, 总检测耗时 0.1518s, 异常检测次数 15198, 检测耗时(每次) 0.0100ms
# Cluster 4: K最近邻评估指标：准确率 0.9982, 精确率 1.0000, 召回率 0.9888, F1 0.9944, ROC AUC 0.9982, 总检测耗时 0.3030s, 异常检测次数 15198, 检测耗时(每次) 0.0199ms
# Cluster 4: 决策树评估指标：准确率 0.9984, 精确率 0.9988, 召回率 0.9912, F1 0.9950, ROC AUC 0.9955, 总检测耗时 0.1539s, 异常检测次数 15198, 检测耗时(每次) 0.0101ms
# Cluster 4: 朴素贝叶斯评估指标：准确率 0.9734, 精确率 0.9323, 召回率 0.9036, F1 0.9177, ROC AUC 0.9918, 总检测耗时 0.0095s, 异常检测次数 15198, 检测耗时(每次) 0.0006ms
# Cluster 4: 逻辑回归评估指标：准确率 0.9500, 精确率 0.8870, 召回率 0.7976, F1 0.8399, ROC AUC 0.9716, 总检测耗时 0.0404s, 异常检测次数 15198, 检测耗时(每次) 0.0027ms
# Cluster 4: XGBoost PRC AUC: 1.0000
# Cluster 4: KNN PRC AUC: 0.9985
# Cluster 4: Decision Tree PRC AUC: 0.9957
# Cluster 4: GaussianNB PRC AUC: 0.9731
# Cluster 4: Logistic Regression PRC AUC: 0.9214
