# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, precision_recall_curve
# from sklearn.preprocessing import StandardScaler
# import xgboost as xgb
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.tree import DecisionTreeClassifier
# from sklearn.naive_bayes import GaussianNB
# from sklearn.linear_model import LogisticRegression
# import time
#
# # 设置字体
# plt.rcParams['font.family'] = 'Times New Roman'
# # 设置字体大小
# plt.rcParams['font.size'] = 16
#
# # 定义函数用于处理每个合并后的 CSV 文件
# def process_cluster(cluster_id):
#     # 加载数据
#     data = pd.read_csv(f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Merged_{cluster_id}.csv')
#
#     # 分离特征和标签
#     X = data.iloc[:, :-1]
#     y = data.iloc[:, -1]
#
#     # 划分训练集和测试集
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
#
#     # 数据标准化
#     scaler = StandardScaler()
#     X_train_scaled = scaler.fit_transform(X_train)
#     X_test_scaled = scaler.transform(X_test)
#
#     # 定义评估指标函数
#     def evaluate_model(y_true, y_pred, y_pred_prob):
#         accuracy = accuracy_score(y_true, y_pred)
#         precision = precision_score(y_true, y_pred)
#         recall = recall_score(y_true, y_pred)
#         f1 = f1_score(y_true, y_pred)
#         fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
#         roc_auc = auc(fpr, tpr)
#         return accuracy, precision, recall, f1, fpr, tpr, roc_auc
#
#     # xgboost
#     start_time = time.time()
#     xgb_clf = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
#     xgb_clf.fit(X_train_scaled, y_train)
#     xgb_pred = xgb_clf.predict(X_test_scaled)
#     end_time = time.time()
#     xgb_total_time = end_time - start_time
#     xgb_detection_count = len(X_test_scaled)
#     xgb_time_per_detection = xgb_total_time / xgb_detection_count * 1000  # 转换成毫秒
#     xgb_pred_prob = xgb_clf.predict_proba(X_test_scaled)[:, 1]
#     xgb_accuracy, xgb_precision, xgb_recall, xgb_f1, xgb_fpr, xgb_tpr, xgb_roc_auc = evaluate_model(y_test, xgb_pred, xgb_pred_prob)
#     print(f"Cluster {cluster_id}: 极致梯度提升树评估指标：准确率 {xgb_accuracy:.4f}, 精确率 {xgb_precision:.4f}, 召回率 {xgb_recall:.4f}, F1 {xgb_f1:.4f}, ROC AUC {xgb_roc_auc:.4f}, 总检测耗时 {xgb_total_time:.4f}s, 异常检测次数 {xgb_detection_count}, 检测耗时(每次) {xgb_time_per_detection:.4f}ms")
#
#     # k最近邻
#     start_time = time.time()
#     knn_clf = KNeighborsClassifier()
#     knn_clf.fit(X_train_scaled, y_train)
#     knn_pred = knn_clf.predict(X_test_scaled)
#     end_time = time.time()
#     knn_total_time = end_time - start_time
#     knn_detection_count = len(X_test_scaled)
#     knn_time_per_detection = knn_total_time / knn_detection_count * 1000
#     knn_pred_prob = knn_clf.predict_proba(X_test_scaled)[:, 1]
#     knn_accuracy, knn_precision, knn_recall, knn_f1, knn_fpr, knn_tpr, knn_roc_auc = evaluate_model(y_test, knn_pred, knn_pred_prob)
#     print(f"Cluster {cluster_id}: K最近邻评估指标：准确率 {knn_accuracy:.4f}, 精确率 {knn_precision:.4f}, 召回率 {knn_recall:.4f}, F1 {knn_f1:.4f}, ROC AUC {knn_roc_auc:.4f}, 总检测耗时 {knn_total_time:.4f}s, 异常检测次数 {knn_detection_count}, 检测耗时(每次) {knn_time_per_detection:.4f}ms")
#
#     # 决策树
#     start_time = time.time()
#     dt_clf = DecisionTreeClassifier()
#     dt_clf.fit(X_train_scaled, y_train)
#     dt_pred = dt_clf.predict(X_test_scaled)
#     end_time = time.time()
#     dt_total_time = end_time - start_time
#     dt_detection_count = len(X_test_scaled)
#     dt_time_per_detection = dt_total_time / dt_detection_count * 1000
#     dt_pred_prob = dt_clf.predict_proba(X_test_scaled)[:, 1]
#     dt_accuracy, dt_precision, dt_recall, dt_f1, dt_fpr, dt_tpr, dt_roc_auc = evaluate_model(y_test, dt_pred, dt_pred_prob)
#     print(f"Cluster {cluster_id}: 决策树评估指标：准确率 {dt_accuracy:.4f}, 精确率 {dt_precision:.4f}, 召回率 {dt_recall:.4f}, F1 {dt_f1:.4f}, ROC AUC {dt_roc_auc:.4f}, 总检测耗时 {dt_total_time:.4f}s, 异常检测次数 {dt_detection_count}, 检测耗时(每次) {dt_time_per_detection:.4f}ms")
#
#     # 朴素贝叶斯
#     start_time = time.time()
#     gnb_clf = GaussianNB()
#     gnb_clf.fit(X_train_scaled, y_train)
#     gnb_pred = gnb_clf.predict(X_test_scaled)
#     end_time = time.time()
#     gnb_total_time = end_time - start_time
#     gnb_detection_count = len(X_test_scaled)
#     gnb_time_per_detection = gnb_total_time / gnb_detection_count * 1000
#     gnb_pred_prob = gnb_clf.predict_proba(X_test_scaled)[:, 1]
#     gnb_accuracy, gnb_precision, gnb_recall, gnb_f1, gnb_fpr, gnb_tpr, gnb_roc_auc = evaluate_model(y_test, gnb_pred, gnb_pred_prob)
#     print(f"Cluster {cluster_id}: 朴素贝叶斯评估指标：准确率 {gnb_accuracy:.4f}, 精确率 {gnb_precision:.4f}, 召回率 {gnb_recall:.4f}, F1 {gnb_f1:.4f}, ROC AUC {gnb_roc_auc:.4f}, 总检测耗时 {gnb_total_time:.4f}s, 异常检测次数 {gnb_detection_count}, 检测耗时(每次) {gnb_time_per_detection:.4f}ms")
#
#     # 逻辑回归
#     start_time = time.time()
#     logreg_clf = LogisticRegression()
#     logreg_clf.fit(X_train_scaled, y_train)
#     logreg_pred = logreg_clf.predict(X_test_scaled)
#     end_time = time.time()
#     logreg_total_time = end_time - start_time
#     logreg_detection_count = len(X_test_scaled)
#     logreg_time_per_detection = logreg_total_time / logreg_detection_count * 1000
#     logreg_pred_prob = logreg_clf.predict_proba(X_test_scaled)[:, 1]
#     logreg_accuracy, logreg_precision, logreg_recall, logreg_f1, logreg_fpr, logreg_tpr, logreg_roc_auc = evaluate_model(y_test, logreg_pred, logreg_pred_prob)
#     print(f"Cluster {cluster_id}: 逻辑回归评估指标：准确率 {logreg_accuracy:.4f}, 精确率 {logreg_precision:.4f}, 召回率 {logreg_recall:.4f}, F1 {logreg_f1:.4f}, ROC AUC {logreg_roc_auc:.4f}, 总检测耗时 {logreg_total_time:.4f}s, 异常检测次数 {logreg_detection_count}, 检测耗时(每次) {logreg_time_per_detection:.4f}ms")
#
#     # 绘制ROC曲线
#     plt.figure(figsize=(10, 6))
#     plt.rcParams['font.family'] = 'Times New Roman'
#
#     # 绘制xgboost的ROC曲线
#     plt.plot(xgb_fpr, xgb_tpr, label='XGBoost (AUC = {:.4f})'.format(xgb_roc_auc), color='#1E90FF', lw=2)
#
#     # 绘制KNN的ROC曲线
#     plt.plot(knn_fpr, knn_tpr, label='KNN (AUC = {:.4f})'.format(knn_roc_auc), color='#8A2BE2', lw=2)
#
#     # 绘制决策树的ROC曲线
#     plt.plot(dt_fpr, dt_tpr, label='Decision Tree (AUC = {:.4f})'.format(dt_roc_auc), color='#20B2AA', lw=2)
#
#     # 绘制朴素贝叶斯的ROC曲线
#     plt.plot(gnb_fpr, gnb_tpr, label='GaussianNB (AUC = {:.4f})'.format(gnb_roc_auc), color='#00CED1', lw=2)
#
#     # 绘制LR的ROC曲线
#     plt.plot(logreg_fpr, logreg_tpr, label='Logistic Regression (AUC = {:.4f})'.format(logreg_roc_auc), color='#DA70D6', lw=2)
#
#     plt.xlabel('False Positive Rate')
#     plt.ylabel('True Positive Rate')
#     plt.title(f'Cluster {cluster_id}: Receiver Operating Characteristic Curve (ROC)')
#     plt.legend(loc="lower right", frameon=False)
#     plt.savefig(f'Cluster{cluster_id}_ROC.svg', format='svg', bbox_inches='tight')
#     plt.show()
#
#     # 绘制PRC曲线
#     plt.figure(figsize=(10, 6))
#     plt.rcParams['font.family'] = 'Times New Roman'
#
#     # 计算xgboost的PRC曲线
#     xgb_precision, xgb_recall, _ = precision_recall_curve(y_test, xgb_pred_prob)
#     xgb_auc = auc(xgb_recall, xgb_precision)
#     plt.plot(xgb_recall, xgb_precision, label='XGBoost (AUC = {:.4f})'.format(xgb_auc), color='#1E90FF', lw=2)
#
#     # 计算KNN的PRC曲线
#     knn_precision, knn_recall, _ = precision_recall_curve(y_test, knn_pred_prob)
#     knn_auc = auc(knn_recall, knn_precision)
#     plt.plot(knn_recall, knn_precision, label='KNN (AUC = {:.4f})'.format(knn_auc), color='#8A2BE2', lw=2)
#
#     # 计算决策树的PRC曲线
#     dt_precision, dt_recall, _ = precision_recall_curve(y_test, dt_pred_prob)
#     dt_auc = auc(dt_recall, dt_precision)
#     plt.plot(dt_recall, dt_precision, label='Decision Tree (AUC = {:.4f})'.format(dt_auc), color='#20B2AA', lw=2)
#
#     # 计算朴素贝叶斯的PRC曲线
#     gnb_precision, gnb_recall, _ = precision_recall_curve(y_test, gnb_pred_prob)
#     gnb_auc = auc(gnb_recall, gnb_precision)
#     plt.plot(gnb_recall, gnb_precision, label='GaussianNB (AUC = {:.4f})'.format(gnb_auc), color='#00CED1', lw=2)
#
#     # 计算LR的PRC曲线
#     logreg_precision, logreg_recall, _ = precision_recall_curve(y_test, logreg_pred_prob)
#     logreg_auc = auc(logreg_recall, logreg_precision)
#     plt.plot(logreg_recall, logreg_precision, label='Logistic Regression (AUC = {:.4f})'.format(logreg_auc), color='#DA70D6', lw=2)
#
#     plt.xlabel('Recall')
#     plt.ylabel('Precision')
#     plt.title(f'Cluster {cluster_id}: Precision Recall Curve (PRC)')
#     plt.legend(loc="lower right", frameon=False)
#     plt.savefig(f'Cluster{cluster_id}_PRC.svg', format='svg', bbox_inches='tight')
#     plt.show()
#
#     # 打印PRC AUC
#     print(f"Cluster {cluster_id}: XGBoost PRC AUC: {xgb_auc:.4f}")
#     print(f"Cluster {cluster_id}: KNN PRC AUC: {knn_auc:.4f}")
#     print(f"Cluster {cluster_id}: Decision Tree PRC AUC: {dt_auc:.4f}")
#     print(f"Cluster {cluster_id}: GaussianNB PRC AUC: {gnb_auc:.4f}")
#     print(f"Cluster {cluster_id}: Logistic Regression PRC AUC: {logreg_auc:.4f}")
#
#
# # 处理每个合并后的 CSV 文件
# for cluster_id in range(1, 5):
#     process_cluster(cluster_id)
#
# # C:\Users\23991\OneDrive\桌面\Python\venv\Scripts\python.exe C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Classification.py
# # Cluster 1: 极致梯度提升树评估指标：准确率 0.9998, 精确率 1.0000, 召回率 0.9985, F1 0.9993, ROC AUC 1.0000, 总检测耗时 0.3838s, 异常检测次数 48368, 检测耗时(每次) 0.0079ms
# # Cluster 1: K最近邻评估指标：准确率 0.9987, 精确率 1.0000, 召回率 0.9920, F1 0.9960, ROC AUC 0.9980, 总检测耗时 0.9956s, 异常检测次数 48368, 检测耗时(每次) 0.0206ms
# # Cluster 1: 决策树评估指标：准确率 0.9993, 精确率 0.9991, 召回率 0.9968, F1 0.9979, ROC AUC 0.9983, 总检测耗时 0.6421s, 异常检测次数 48368, 检测耗时(每次) 0.0133ms
# # Cluster 1: 朴素贝叶斯评估指标：准确率 0.9395, 精确率 0.7908, 召回率 0.8650, F1 0.8262, ROC AUC 0.9803, 总检测耗时 0.0241s, 异常检测次数 48368, 检测耗时(每次) 0.0005ms
# # C:\Users\23991\OneDrive\桌面\Python\venv\lib\site-packages\sklearn\metrics\_classification.py:1344: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 due to no predicted samples. Use `zero_division` parameter to control this behavior.
# #   _warn_prf(average, modifier, msg_start, len(result))
# # Cluster 1: 逻辑回归评估指标：准确率 0.8337, 精确率 0.0000, 召回率 0.0000, F1 0.0000, ROC AUC 0.6042, 总检测耗时 0.1001s, 异常检测次数 48368, 检测耗时(每次) 0.0021ms
# # Cluster 1: XGBoost PRC AUC: 0.9999
# # Cluster 1: KNN PRC AUC: 0.9983
# # Cluster 1: Decision Tree PRC AUC: 0.9982
# # Cluster 1: GaussianNB PRC AUC: 0.9041
# # Cluster 1: Logistic Regression PRC AUC: 0.1798
# # Cluster 2: 极致梯度提升树评估指标：准确率 0.9989, 精确率 0.9996, 召回率 0.9938, F1 0.9967, ROC AUC 1.0000, 总检测耗时 0.3197s, 异常检测次数 14606, 检测耗时(每次) 0.0219ms
# # Cluster 2: K最近邻评估指标：准确率 0.9954, 精确率 1.0000, 召回率 0.9721, F1 0.9859, ROC AUC 0.9944, 总检测耗时 0.6078s, 异常检测次数 14606, 检测耗时(每次) 0.0416ms
# # Cluster 2: 决策树评估指标：准确率 0.9978, 精确率 0.9979, 召回率 0.9888, F1 0.9933, ROC AUC 0.9942, 总检测耗时 0.1994s, 异常检测次数 14606, 检测耗时(每次) 0.0137ms
# # Cluster 2: 朴素贝叶斯评估指标：准确率 0.9067, 精确率 0.6808, 召回率 0.8153, F1 0.7420, ROC AUC 0.9585, 总检测耗时 0.0132s, 异常检测次数 14606, 检测耗时(每次) 0.0009ms
# # Cluster 2: 逻辑回归评估指标：准确率 0.8364, 精确率 0.5155, 召回率 0.1036, F1 0.1725, ROC AUC 0.8032, 总检测耗时 0.0449s, 异常检测次数 14606, 检测耗时(每次) 0.0031ms
# # Cluster 2: XGBoost PRC AUC: 1.0000
# # Cluster 2: KNN PRC AUC: 0.9953
# # Cluster 2: Decision Tree PRC AUC: 0.9943
# # Cluster 2: GaussianNB PRC AUC: 0.8442
# # Cluster 2: Logistic Regression PRC AUC: 0.3945
# # Cluster 3: 极致梯度提升树评估指标：准确率 0.9994, 精确率 1.0000, 召回率 0.9962, F1 0.9981, ROC AUC 1.0000, 总检测耗时 0.1893s, 异常检测次数 22991, 检测耗时(每次) 0.0082ms
# # Cluster 3: K最近邻评估指标：准确率 0.9986, 精确率 0.9994, 召回率 0.9918, F1 0.9956, ROC AUC 0.9980, 总检测耗时 0.4420s, 异常检测次数 22991, 检测耗时(每次) 0.0192ms
# # Cluster 3: 决策树评估指标：准确率 0.9993, 精确率 0.9997, 召回率 0.9956, F1 0.9977, ROC AUC 0.9978, 总检测耗时 0.2039s, 异常检测次数 22991, 检测耗时(每次) 0.0089ms
# # Cluster 3: 朴素贝叶斯评估指标：准确率 0.9714, 精确率 0.9627, 召回率 0.8536, F1 0.9049, ROC AUC 0.9935, 总检测耗时 0.0145s, 异常检测次数 22991, 检测耗时(每次) 0.0006ms
# # C:\Users\23991\OneDrive\桌面\Python\venv\lib\site-packages\sklearn\metrics\_classification.py:1344: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 due to no predicted samples. Use `zero_division` parameter to control this behavior.
# #   _warn_prf(average, modifier, msg_start, len(result))
# # Cluster 3: 逻辑回归评估指标：准确率 0.8407, 精确率 0.0000, 召回率 0.0000, F1 0.0000, ROC AUC 0.6822, 总检测耗时 0.0495s, 异常检测次数 22991, 检测耗时(每次) 0.0022ms
# # Cluster 3: XGBoost PRC AUC: 1.0000
# # Cluster 3: KNN PRC AUC: 0.9983
# # Cluster 3: Decision Tree PRC AUC: 0.9980
# # Cluster 3: GaussianNB PRC AUC: 0.9755
# # Cluster 3: Logistic Regression PRC AUC: 0.2080
# # Cluster 4: 极致梯度提升树评估指标：准确率 0.9988, 精确率 1.0000, 召回率 0.9932, F1 0.9966, ROC AUC 1.0000, 总检测耗时 0.1133s, 异常检测次数 8571, 检测耗时(每次) 0.0132ms
# # Cluster 4: K最近邻评估指标：准确率 0.9965, 精确率 1.0000, 召回率 0.9796, F1 0.9897, ROC AUC 0.9952, 总检测耗时 0.1743s, 异常检测次数 8571, 检测耗时(每次) 0.0203ms
# # Cluster 4: 决策树评估指标：准确率 0.9978, 精确率 0.9986, 召回率 0.9885, F1 0.9935, ROC AUC 0.9941, 总检测耗时 0.0603s, 异常检测次数 8571, 检测耗时(每次) 0.0070ms
# # Cluster 4: 朴素贝叶斯评估指标：准确率 0.9123, 精确率 0.7015, 召回率 0.8520, F1 0.7695, ROC AUC 0.9634, 总检测耗时 0.0049s, 异常检测次数 8571, 检测耗时(每次) 0.0006ms
# # Cluster 4: 逻辑回归评估指标：准确率 0.8028, 精确率 0.1556, 召回率 0.0333, F1 0.0548, ROC AUC 0.8182, 总检测耗时 0.0210s, 异常检测次数 8571, 检测耗时(每次) 0.0025ms
# # Cluster 4: XGBoost PRC AUC: 0.9999
# # Cluster 4: KNN PRC AUC: 0.9961
# # Cluster 4: Decision Tree PRC AUC: 0.9945
# # Cluster 4: GaussianNB PRC AUC: 0.8557
# # Cluster 4: Logistic Regression PRC AUC: 0.3299
# # Cluster 5: 极致梯度提升树评估指标：准确率 0.9999, 精确率 1.0000, 召回率 0.9991, F1 0.9996, ROC AUC 1.0000, 总检测耗时 0.2074s, 异常检测次数 26960, 检测耗时(每次) 0.0077ms
# # Cluster 5: K最近邻评估指标：准确率 0.9995, 精确率 1.0000, 召回率 0.9971, F1 0.9985, ROC AUC 0.9994, 总检测耗时 0.5450s, 异常检测次数 26960, 检测耗时(每次) 0.0202ms
# # Cluster 5: 决策树评估指标：准确率 0.9995, 精确率 1.0000, 召回率 0.9971, F1 0.9985, ROC AUC 0.9985, 总检测耗时 0.2667s, 异常检测次数 26960, 检测耗时(每次) 0.0099ms
# # Cluster 5: 朴素贝叶斯评估指标：准确率 0.9709, 精确率 1.0000, 召回率 0.8247, F1 0.9039, ROC AUC 0.9944, 总检测耗时 0.0161s, 异常检测次数 26960, 检测耗时(每次) 0.0006ms
# # Cluster 5: 逻辑回归评估指标：准确率 0.8316, 精确率 0.1684, 召回率 0.0036, F1 0.0070, ROC AUC 0.6850, 总检测耗时 0.0561s, 异常检测次数 26960, 检测耗时(每次) 0.0021ms
# # Cluster 5: XGBoost PRC AUC: 1.0000
# # Cluster 5: KNN PRC AUC: 0.9995
# # Cluster 5: Decision Tree PRC AUC: 0.9988
# # Cluster 5: GaussianNB PRC AUC: 0.9804
# # Cluster 5: Logistic Regression PRC AUC: 0.2575

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, precision_recall_curve
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from sklearn.linear_model import Perceptron
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
import time

# 设置字体
plt.rcParams['font.family'] = 'Times New Roman'  # 设置字体为Times New Roman
# 设置字体大小
plt.rcParams['font.size'] = 16

# 定义函数用于处理每个合并后的 CSV 文件
def process_cluster(cluster_id):
    # 加载数据
    data = pd.read_csv(f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_1/Merged_{cluster_id}.csv')

    # 分离特征和标签
    X = data.iloc[:, :-1]
    y = data.iloc[:, -1]

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 数据标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 定义评估指标函数
    def evaluate_model(y_true, y_pred, y_pred_prob):
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred)
        recall = recall_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred)
        fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
        roc_auc = auc(fpr, tpr)
        return accuracy, precision, recall, f1, fpr, tpr, roc_auc

    # xgboost
    start_time = time.time()
    xgb_clf = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    xgb_clf.fit(X_train_scaled, y_train)
    xgb_pred = xgb_clf.predict(X_test_scaled)
    end_time = time.time()
    xgb_total_time = end_time - start_time
    xgb_detection_count = len(X_test_scaled)
    xgb_time_per_detection = xgb_total_time / xgb_detection_count * 1000  # 转换成毫秒
    xgb_pred_prob = xgb_clf.predict_proba(X_test_scaled)[:, 1]
    xgb_accuracy, xgb_precision, xgb_recall, xgb_f1, xgb_fpr, xgb_tpr, xgb_roc_auc = evaluate_model(y_test, xgb_pred, xgb_pred_prob)
    print(f"Cluster {cluster_id}: 极致梯度提升树评估指标：准确率 {xgb_accuracy:.4f}, 精确率 {xgb_precision:.4f}, 召回率 {xgb_recall:.4f}, F1 {xgb_f1:.4f}, ROC AUC {xgb_roc_auc:.4f}, 总检测耗时 {xgb_total_time:.4f}s, 异常检测次数 {xgb_detection_count}, 检测耗时(每次) {xgb_time_per_detection:.4f}ms")

    # # 支持向量机
    # start_time = time.time()
    # svm_clf = SVC(probability=True)
    # svm_clf.fit(X_train_scaled, y_train)
    # svm_pred = svm_clf.predict(X_test_scaled)
    # end_time = time.time()
    # svm_total_time = end_time - start_time
    # svm_detection_count = len(X_test_scaled)
    # svm_time_per_detection = svm_total_time / svm_detection_count * 1000
    # svm_pred_prob = svm_clf.predict_proba(X_test_scaled)[:, 1]
    # svm_accuracy, svm_precision, svm_recall, svm_f1, svm_fpr, svm_tpr, svm_roc_auc = evaluate_model(y_test, svm_pred, svm_pred_prob)
    # print("支持向量机评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(svm_accuracy, svm_precision, svm_recall, svm_f1, svm_roc_auc, svm_total_time, svm_detection_count, svm_time_per_detection))

    # # k最近邻
    # start_time = time.time()
    # knn_clf = KNeighborsClassifier()
    # knn_clf.fit(X_train_scaled, y_train)
    # knn_pred = knn_clf.predict(X_test_scaled)
    # end_time = time.time()
    # knn_total_time = end_time - start_time
    # knn_detection_count = len(X_test_scaled)
    # knn_time_per_detection = knn_total_time / knn_detection_count * 1000
    # knn_pred_prob = knn_clf.predict_proba(X_test_scaled)[:, 1]
    # knn_accuracy, knn_precision, knn_recall, knn_f1, knn_fpr, knn_tpr, knn_roc_auc = evaluate_model(y_test, knn_pred, knn_pred_prob)
    # print("K最近邻评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(knn_accuracy, knn_precision, knn_recall, knn_f1, knn_roc_auc, knn_total_time, knn_detection_count, knn_time_per_detection))

    # # 决策树
    # start_time = time.time()
    # dt_clf = DecisionTreeClassifier()
    # dt_clf.fit(X_train_scaled, y_train)
    # dt_pred = dt_clf.predict(X_test_scaled)
    # end_time = time.time()
    # dt_total_time = end_time - start_time
    # dt_detection_count = len(X_test_scaled)
    # dt_time_per_detection = dt_total_time / dt_detection_count * 1000
    # dt_pred_prob = dt_clf.predict_proba(X_test_scaled)[:, 1]
    # dt_accuracy, dt_precision, dt_recall, dt_f1, dt_fpr, dt_tpr, dt_roc_auc = evaluate_model(y_test, dt_pred, dt_pred_prob)
    # print("决策树评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(dt_accuracy, dt_precision, dt_recall, dt_f1, dt_roc_auc, dt_total_time, dt_detection_count, dt_time_per_detection))

    # 朴素贝叶斯
    start_time = time.time()
    gnb_clf = GaussianNB()
    gnb_clf.fit(X_train_scaled, y_train)
    gnb_pred = gnb_clf.predict(X_test_scaled)
    end_time = time.time()
    gnb_total_time = end_time - start_time
    gnb_detection_count = len(X_test_scaled)
    gnb_time_per_detection = gnb_total_time / gnb_detection_count * 1000
    gnb_pred_prob = gnb_clf.predict_proba(X_test_scaled)[:, 1]
    gnb_accuracy, gnb_precision, gnb_recall, gnb_f1, gnb_fpr, gnb_tpr, gnb_roc_auc = evaluate_model(y_test, gnb_pred, gnb_pred_prob)
    print(f"Cluster {cluster_id}: 朴素贝叶斯评估指标：准确率 {gnb_accuracy:.4f}, 精确率 {gnb_precision:.4f}, 召回率 {gnb_recall:.4f}, F1 {gnb_f1:.4f}, ROC AUC {gnb_roc_auc:.4f}, 总检测耗时 {gnb_total_time:.4f}s, 异常检测次数 {gnb_detection_count}, 检测耗时(每次) {gnb_time_per_detection:.4f}ms")

    # 逻辑回归
    start_time = time.time()
    logreg_clf = LogisticRegression()
    logreg_clf.fit(X_train_scaled, y_train)
    logreg_pred = logreg_clf.predict(X_test_scaled)
    end_time = time.time()
    logreg_total_time = end_time - start_time
    logreg_detection_count = len(X_test_scaled)
    logreg_time_per_detection = logreg_total_time / logreg_detection_count * 1000
    logreg_pred_prob = logreg_clf.predict_proba(X_test_scaled)[:, 1]
    logreg_accuracy, logreg_precision, logreg_recall, logreg_f1, logreg_fpr, logreg_tpr, logreg_roc_auc = evaluate_model(y_test, logreg_pred, logreg_pred_prob)
    print(f"Cluster {cluster_id}: 逻辑回归评估指标：准确率 {logreg_accuracy:.4f}, 精确率 {logreg_precision:.4f}, 召回率 {logreg_recall:.4f}, F1 {logreg_f1:.4f}, ROC AUC {logreg_roc_auc:.4f}, 总检测耗时 {logreg_total_time:.4f}s, 异常检测次数 {logreg_detection_count}, 检测耗时(每次) {logreg_time_per_detection:.4f}ms")

    # 感知机
    start_time = time.time()
    perceptron_clf = Perceptron()
    perceptron_clf.fit(X_train_scaled, y_train)
    perceptron_pred = perceptron_clf.predict(X_test_scaled)
    end_time = time.time()
    perceptron_total_time = end_time - start_time
    perceptron_detection_count = len(X_test_scaled)
    perceptron_time_per_detection = perceptron_total_time / perceptron_detection_count * 1000
    # 感知机没有 predict_proba 方法，因此使用决策函数值来计算假阳性率和真阳性率
    perceptron_decision = perceptron_clf.decision_function(X_test_scaled)
    perceptron_fpr, perceptron_tpr, _ = roc_curve(y_test, perceptron_decision)
    perceptron_roc_auc = auc(perceptron_fpr, perceptron_tpr)
    # 计算其他评估指标
    perceptron_accuracy = accuracy_score(y_test, perceptron_pred)
    perceptron_precision = precision_score(y_test, perceptron_pred)
    perceptron_recall = recall_score(y_test, perceptron_pred)
    perceptron_f1 = f1_score(y_test, perceptron_pred)
    print(f"Cluster {cluster_id}: 感知机评估指标：准确率 {perceptron_accuracy:.4f}, 精确率 {perceptron_precision:.4f}, 召回率 {perceptron_recall:.4f}, F1 {perceptron_f1:.4f}, ROC AUC {perceptron_roc_auc:.4f}, 总检测耗时 {perceptron_total_time:.4f}s, 异常检测次数 {perceptron_detection_count}, 检测耗时(每次) {perceptron_time_per_detection:.4f}ms")

    # 绘制ROC曲线
    plt.figure(figsize=(10, 6))

    # 绘制xgboost的ROC曲线
    plt.plot(xgb_fpr, xgb_tpr, label='XGBoost(AUC = {:.4f})'.format(xgb_roc_auc), color='#FFA07A', lw=2)

    # # 绘制SVM的ROC曲线
    # plt.plot(svm_fpr, svm_tpr, label='支持向量机 (AUC = {:.4f})'.format(svm_roc_auc), color='#FF69B4', lw=2)

    # # 绘制KNN的ROC曲线
    # plt.plot(knn_fpr, knn_tpr, label='KNN (AUC = {:.4f})'.format(knn_roc_auc), color='#D6E4AA', lw=2)

    # # 绘制决策树的ROC曲线
    # plt.plot(dt_fpr, dt_tpr, label='决策树 (AUC = {:.4f})'.format(dt_roc_auc), color='#F8E6FF', lw=2)

    # 绘制朴素贝叶斯的ROC曲线
    plt.plot(gnb_fpr, gnb_tpr, label='GaussianNB(AUC = {:.4f})'.format(gnb_roc_auc), color='#BA55D3', lw=2)

    # 绘制LR的ROC曲线
    plt.plot(logreg_fpr, logreg_tpr, label='Logistic Regression(AUC = {:.4f})'.format(logreg_roc_auc), color='#7ED8E5', lw=2)

    # 绘制感知机的ROC曲线
    plt.plot(perceptron_fpr, perceptron_tpr, label='Perceptron(AUC = {:.4f})'.format(perceptron_roc_auc), color='#B4F8C8', lw=2)

    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'Cluster {cluster_id}: Receiver Operating Characteristic Curve (ROC)')
    plt.legend(loc="lower right", frameon=False)
    plt.savefig(f'Cluster{cluster_id}_ROC.svg', format='svg', bbox_inches='tight')
    plt.show()

    # 绘制PRC曲线
    plt.figure(figsize=(10, 6))

    # 计算xgboost的PRC曲线
    xgb_precision, xgb_recall, _ = precision_recall_curve(y_test, xgb_pred_prob)
    xgb_auc = auc(xgb_recall, xgb_precision)
    plt.plot(xgb_recall, xgb_precision, label='XGBoost(AUC = {:.4f})'.format(xgb_auc), color='#FFA07A', lw=2)

    # # 计算SVM的PRC曲线
    # svm_precision, svm_recall, _ = precision_recall_curve(y_test, svm_pred_prob)
    # svm_auc = auc(svm_recall, svm_precision)
    # plt.plot(svm_recall, svm_precision, label='支持向量机 (AUC = {:.4f})'.format(svm_auc), color='#FF69B4', lw=2)

    # # 计算KNN的PRC曲线
    # knn_precision, knn_recall, _ = precision_recall_curve(y_test, knn_pred_prob)
    # knn_auc = auc(knn_recall, knn_precision)
    # plt.plot(knn_recall, knn_precision, label='KNN (AUC = {:.4f})'.format(knn_auc), color='#D6E4AA', lw=2)

    # # 计算决策树的PRC曲线
    # dt_precision, dt_recall, _ = precision_recall_curve(y_test, dt_pred_prob)
    # dt_auc = auc(dt_recall, dt_precision)
    # plt.plot(dt_recall, dt_precision, label='决策树 (AUC = {:.4f})'.format(dt_auc), color='#F8E6FF', lw=2)

    # 计算朴素贝叶斯的PRC曲线
    gnb_precision, gnb_recall, _ = precision_recall_curve(y_test, gnb_pred_prob)
    gnb_auc = auc(gnb_recall, gnb_precision)
    plt.plot(gnb_recall, gnb_precision, label='GaussianNB(AUC = {:.4f})'.format(gnb_auc), color='#BA55D3', lw=2)

    # 计算LR的PRC曲线
    logreg_precision, logreg_recall, _ = precision_recall_curve(y_test, logreg_pred_prob)
    logreg_auc = auc(logreg_recall, logreg_precision)
    plt.plot(logreg_recall, logreg_precision, label='Logistic Regression(AUC = {:.4f})'.format(logreg_auc), color='#7ED8E5', lw=2)

    # 计算感知机的PRC曲线
    perceptron_precision_curve, perceptron_recall_curve, _ = precision_recall_curve(y_test, perceptron_decision)
    perceptron_prc_auc = auc(perceptron_recall_curve, perceptron_precision_curve)
    plt.plot(perceptron_recall_curve, perceptron_precision_curve, label='Perceptron(AUC = {:.4f})'.format(perceptron_prc_auc), color='#B4F8C8', lw=2)

    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title(f'Cluster {cluster_id}: Precision Recall Curve (PRC)')
    plt.legend(loc="lower right", frameon=False)
    plt.savefig(f'Cluster{cluster_id}_PRC.svg', format='svg', bbox_inches='tight')
    plt.show()

    # 打印PRC AUC
    print("XGBoost PRC AUC: {:.4f}".format(xgb_auc))
    # print("SVM PRC AUC: {:.4f}".format(svm_auc))
    # print("KNN PRC AUC: {:.4f}".format(knn_auc))
    # print("Decision Tree PRC AUC: {:.4f}".format(dt_auc))
    print("GaussianNB PRC AUC: {:.4f}".format(gnb_auc))
    print("Logistic Regression PRC AUC: {:.4f}".format(logreg_auc))
    print("Perceptron PRC AUC: {:.4f}".format(perceptron_prc_auc))

# 处理每个合并后的 CSV 文件
for cluster_id in range(1, 5):
    process_cluster(cluster_id)

# Cluster 1: 极致梯度提升树评估指标：准确率 0.9996, 精确率 1.0000, 召回率 0.9976, F1 0.9988, ROC AUC 1.0000, 总检测耗时 0.0934s, 异常检测次数 12287, 检测耗时(每次) 0.0076ms
# Cluster 1: 朴素贝叶斯评估指标：准确率 0.9842, 精确率 0.9533, 召回率 0.9542, F1 0.9538, ROC AUC 0.9983, 总检测耗时 0.0100s, 异常检测次数 12287, 检测耗时(每次) 0.0008ms
# Cluster 1: 逻辑回归评估指标：准确率 0.8971, 精确率 0.7216, 召回率 0.6473, F1 0.6824, ROC AUC 0.9479, 总检测耗时 0.0319s, 异常检测次数 12287, 检测耗时(每次) 0.0026ms
# Cluster 1: 感知机评估指标：准确率 0.8625, 精确率 0.6885, 召回率 0.3551, F1 0.4686, ROC AUC 0.9398, 总检测耗时 0.0140s, 异常检测次数 12287, 检测耗时(每次) 0.0011ms
# XGBoost PRC AUC: 1.0000
# GaussianNB PRC AUC: 0.9927
# Logistic Regression PRC AUC: 0.6688
# Perceptron PRC AUC: 0.6311
# Cluster 2: 极致梯度提升树评估指标：准确率 0.9981, 精确率 0.9947, 召回率 0.9936, F1 0.9941, ROC AUC 1.0000, 总检测耗时 0.1739s, 异常检测次数 22962, 检测耗时(每次) 0.0076ms
# Cluster 2: 朴素贝叶斯评估指标：准确率 0.9222, 精确率 0.7134, 召回率 0.8774, F1 0.7869, ROC AUC 0.9699, 总检测耗时 0.0161s, 异常检测次数 22962, 检测耗时(每次) 0.0007ms
# Cluster 2: 逻辑回归评估指标：准确率 0.8317, 精确率 0.3992, 召回率 0.0553, F1 0.0972, ROC AUC 0.7554, 总检测耗时 0.0357s, 异常检测次数 22962, 检测耗时(每次) 0.0016ms
# Cluster 2: 感知机评估指标：准确率 0.7338, 精确率 0.1392, 召回率 0.1208, F1 0.1293, ROC AUC 0.7332, 总检测耗时 0.0312s, 异常检测次数 22962, 检测耗时(每次) 0.0014ms
# XGBoost PRC AUC: 0.9998
# GaussianNB PRC AUC: 0.8880
# Logistic Regression PRC AUC: 0.3360
# Perceptron PRC AUC: 0.2439
# Cluster 3: 极致梯度提升树评估指标：准确率 0.9985, 精确率 0.9996, 召回率 0.9916, F1 0.9956, ROC AUC 0.9999, 总检测耗时 0.1922s, 异常检测次数 27149, 检测耗时(每次) 0.0071ms
# Cluster 3: 朴素贝叶斯评估指标：准确率 0.9675, 精确率 0.9095, 召回率 0.8943, F1 0.9018, ROC AUC 0.9891, 总检测耗时 0.0176s, 异常检测次数 27149, 检测耗时(每次) 0.0006ms
# Cluster 3: 逻辑回归评估指标：准确率 0.8038, 精确率 0.2059, 召回率 0.0616, F1 0.0948, ROC AUC 0.8564, 总检测耗时 0.0530s, 异常检测次数 27149, 检测耗时(每次) 0.0020ms
# Cluster 3: 感知机评估指标：准确率 0.7267, 精确率 0.3217, 召回率 0.5755, F1 0.4127, ROC AUC 0.7554, 总检测耗时 0.0313s, 异常检测次数 27149, 检测耗时(每次) 0.0012ms
# XGBoost PRC AUC: 0.9998
# GaussianNB PRC AUC: 0.9609
# Logistic Regression PRC AUC: 0.3932
# Perceptron PRC AUC: 0.3156
# Cluster 4: 极致梯度提升树评估指标：准确率 0.9994, 精确率 1.0000, 召回率 0.9964, F1 0.9982, ROC AUC 1.0000, 总检测耗时 0.1185s, 异常检测次数 15198, 检测耗时(每次) 0.0078ms
# Cluster 4: 朴素贝叶斯评估指标：准确率 0.9734, 精确率 0.9323, 召回率 0.9036, F1 0.9177, ROC AUC 0.9918, 总检测耗时 0.0090s, 异常检测次数 15198, 检测耗时(每次) 0.0006ms
# Cluster 4: 逻辑回归评估指标：准确率 0.9500, 精确率 0.8870, 召回率 0.7976, F1 0.8399, ROC AUC 0.9716, 总检测耗时 0.0366s, 异常检测次数 15198, 检测耗时(每次) 0.0024ms
# Cluster 4: 感知机评估指标：准确率 0.9277, 精确率 0.7603, 召回率 0.8184, F1 0.7883, ROC AUC 0.9539, 总检测耗时 0.0191s, 异常检测次数 15198, 检测耗时(每次) 0.0013ms
# XGBoost PRC AUC: 1.0000
# GaussianNB PRC AUC: 0.9731
# Logistic Regression PRC AUC: 0.9214
# Perceptron PRC AUC: 0.8729

# 平均总检测耗时0.1576s，平均每次检测耗时0.0084ms

