import pandas as pd
from sklearn.cluster import KMeans

# 读取聚类结果的CSV文件
file_path = "聚类结果.csv"
data = pd.read_csv(file_path)

# 根据聚类结果将数据分成不同的DataFrame
clusters = {}
for cluster_id in data['Cluster'].unique():
    clusters[cluster_id] = data[data['Cluster'] == cluster_id].copy()

# 将每个聚类簇保存为不同的CSV文件，并删除 'Cluster' 列
for cluster_id, cluster_data in clusters.items():
    # 删除 'Cluster' 列
    cluster_data.drop(columns=['Cluster'], inplace=True)
    # 保存 CSV 文件
    file_name = f"Cluster{cluster_id}.csv"
    cluster_data.to_csv(file_name, index=False)
