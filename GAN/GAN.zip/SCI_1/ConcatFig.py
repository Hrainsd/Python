import matplotlib.pyplot as plt
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from reportlab.graphics import renderPDF, renderPM
from reportlab.graphics.shapes import Drawing
import os

# 图像文件路径
image_paths = [
    r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Loss_Curves_Cluster0.svg",
    r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Loss_Curves_Cluster1.svg",
    r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Loss_Curves_Cluster2.svg",
    r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Loss_Curves_Cluster3.svg",
    r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\Loss_Curves_Cluster4.svg",
]

# 创建画布
fig, ax = plt.subplots()

# 遍历图像路径并将图像添加到画布中
for i, image_path in enumerate(image_paths):
    if os.path.exists(image_path):
        drawing = Drawing()
        drawing.add(renderPDF.svg2rlg(image_path))
        renderPM.drawToFile(drawing, "temp.png", fmt="PNG")  # 将SVG文件转换为PNG格式
        img = plt.imread("temp.png")
        os.remove("temp.png")  # 删除临时PNG文件
        imagebox = OffsetImage(img, zoom=0.5)
        ab = AnnotationBbox(imagebox, (i * 0.2, 0.5), frameon=False, pad=0.1)
        ax.add_artist(ab)

# 设置标题和标签
plt.title('Combined Loss Curves')
plt.xlabel('Cluster')
plt.ylabel('Loss')

# 隐藏坐标轴
plt.xticks([])
plt.yticks([])

# 显示图形
plt.show()
