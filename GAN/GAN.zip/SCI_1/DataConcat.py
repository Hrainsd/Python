import pandas as pd

# 定义函数用于处理每个簇数据
def process_cluster(cluster_id):
    # 定义文件路径
    file_path_cluster = f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Cluster{cluster_id}.csv'
    file_path_generated = f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Generated_Cluster{cluster_id}.csv'
    output_file_path_normal = f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Cluster{cluster_id}.1.csv'
    output_file_path_anomaly = f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Generated_Cluster{cluster_id}.1.csv'
    output_file_path_merged = f'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/Sci_gan/Merged_{cluster_id}.csv'

    # 读取正常数据文件并添加 Label 列
    df_cluster = pd.read_csv(file_path_cluster)
    df_cluster['Label'] = 0
    df_cluster.to_csv(output_file_path_normal, index=False)

    # 读取生成的异常数据文件并添加 Label 列
    df_generated = pd.read_csv(file_path_generated)
    df_generated['Label'] = 1
    df_generated.to_csv(output_file_path_anomaly, index=False)

    print(f"Cluster {cluster_id}: 新列已添加并保存到新的CSV文件中。")

    # 读取两个 CSV 文件
    df_normal = pd.read_csv(output_file_path_normal)
    df_anomaly = pd.read_csv(output_file_path_anomaly)

    # 合并两个 DataFrame
    merged_df = pd.concat([df_normal, df_anomaly])

    # 将合并后的 DataFrame 保存为新的 CSV 文件
    merged_df.to_csv(output_file_path_merged, index=False)
    print(f"Cluster {cluster_id}: 合并后的数据保存到 {output_file_path_merged}")

# 循环处理每个簇数据
for cluster_id in range(1, 5):
    process_cluster(cluster_id)
