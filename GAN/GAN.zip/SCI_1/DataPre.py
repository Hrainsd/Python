import pandas as pd

# 读取CSV文件
file_path = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\20190615-183621.csv"
df = pd.read_csv(file_path).dropna()

# 保存去除空值样本后的数据到CSV文件中
df.to_csv("1.csv", index=False)