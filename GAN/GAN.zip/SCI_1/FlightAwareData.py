# import os
# import pandas as pd
#
# # 设置文件夹路径
# folder_path = r'D:\大学\SCI\CSV'
#
# # 获取文件夹中所有CSV文件的路径
# csv_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.csv')]
#
# # 创建一个空的DataFrame，用于存储所有CSV文件的内容
# combined_data = pd.concat([pd.read_csv(file) for file in csv_files], ignore_index=True)
#
# # 将合并后的数据保存为一个新的CSV文件
# combined_data.to_csv('combined_data.csv', index=False)

# import pandas as pd
#
# # 读取combined_data.csv文件
# data = pd.read_csv('combined_data.csv')
#
# # 提取所需列到一个新的DataFrame
# extracted_data = data[['Longitude', 'Latitude', 'Height', 'Speed', 'Angle']]
#
# # 重命名列
# extracted_data.columns = ['Column1', 'Column2', 'Column3', 'Column4', 'Column5']
#
# # 将提取的数据保存到1.csv文件中
# extracted_data.to_csv('1.csv', index=False)

import pandas as pd

# 读取combined_data.csv文件
data = pd.read_csv('combined_data.csv')

# 提取所需列到一个新的DataFrame
extracted_data = data[['Longitude', 'Latitude', 'Height', 'Speed', 'Angle']]

# 重命名列
extracted_data.columns = ['Column1', 'Column2', 'Column3', 'Column4', 'Column5']

# 根据条件过滤数据
extracted_data_filtered = extracted_data[extracted_data['Column1'] < -75]

# 将过滤后的数据保存到1.csv文件中
extracted_data_filtered.to_csv('1.csv', index=False)
