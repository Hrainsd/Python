import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# 设置字体
plt.rcParams['font.family'] = 'Times New Roman'
# 设置字体大小
plt.rcParams['font.size'] = 16

# 读取去除空值样本后的CSV文件
file_path = r"C:\Users\23991\OneDrive\桌面\Python\venv\shuxuejianmo\shu_xue_jian_mo\Sci_gan\1.csv"
data = pd.read_csv(file_path)

# 提取特征数据
X = data[['Column1', 'Column2']].values  # 提取经度、纬度

# # 使用 KMeans 进行聚类
# max_clusters = 10
# losses = []
# for k in range(1, max_clusters + 1):
#     kmeans = KMeans(n_clusters=k, init='k-means++')  # 使用 KMeans++ 初始化
#     kmeans.fit(X)
#     losses.append(kmeans.inertia_)
#
# # 绘制损失函数值（误差平方和）随聚类数量变化的曲线图
# plt.plot(range(1, max_clusters + 1), losses, marker='o', color='#9AD9CA')
# plt.title('Elbow curve')
# plt.xlabel('Number of Clusters')
# plt.ylabel('Loss')
# plt.xticks(range(1, max_clusters + 1))
# plt.savefig('肘部法结果图.svg', format='svg')
# plt.show()

# 重新选择类数
k = 4
kmeans = KMeans(n_clusters=k, init='k-means++')
labels = kmeans.fit_predict(X)

# 将聚类结果添加到原始数据中
data['Cluster'] = labels + 1  # 类数从1开始

# 保存带有聚类结果的数据到CSV文件中
data.to_csv("聚类结果.csv", index=False)

# 定义颜色
colors = ['#70C1B3', '#DB7093', '#9C8FBC', '#F25F5C', '#27AE60', '#D7E9FD', '#FEEAFA', '#C3AED6']

# 可视化聚类结果
for cluster_id in range(1, k + 1):  # 类数从1开始
    plt.scatter(data[data['Cluster'] == cluster_id]['Column1'], data[data['Cluster'] == cluster_id]['Column2'], color=colors[cluster_id - 1], label=f'Cluster {cluster_id}', s=0.1)

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.legend(markerscale=30, frameon = False)
# plt.savefig('聚类结果图.svg', format='svg')
plt.show()

# # 循环绘制每个类别的图
# for cluster_id in range(1, k + 1):  # 类数从1开始
#     # 提取当前类别的数据
#     cluster_data = data[data['Cluster'] == cluster_id]
#
#     # 按照高度从低到高排序
#     sorted_cluster_data = cluster_data.sort_values(by='Column3')
#
#     # 绘制当前类别的图
#     plt.scatter(np.arange(len(sorted_cluster_data)), sorted_cluster_data['Column3'], color=colors[cluster_id - 1],
#                 label=f'Cluster {cluster_id}', s=0.1)
#
#     # 设置图标题和轴标签
#     plt.title(f'Cluster {cluster_id}')
#     plt.xlabel('Sequence Number')
#     plt.ylabel('Height')
#
#     # 显示图例
#     plt.legend(markerscale=30, frameon=False)
#
#     # 保存图像
#     plt.savefig(f'Cluster_{cluster_id}_alt_plot.svg', format='svg')
#
#     # 显示图像
#     plt.show()


# # 可视化3D聚类结果
# fig = plt.figure()
# ax = fig.add_subplot(111, projection='3d')
#
# for cluster_id in range(1, k + 1):  # Cluster numbering starting from 1
#     ax.scatter(data[data['Cluster'] == cluster_id]['Column1'], data[data['Cluster'] == cluster_id]['Column2'], data[data['Cluster'] == cluster_id]['Column3'], color=colors[cluster_id - 1], label=f'Cluster {cluster_id}', s=0.01)
#
# ax.set_xlabel('Longitude')
# ax.set_ylabel('Latitude')
# ax.set_zlabel('Altitude')
# ax.legend(markerscale=50)
#
# plt.show()
