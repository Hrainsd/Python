import matplotlib.pyplot as plt

# 设置字体
plt.rcParams['font.family'] = 'Times New Roman'
# 设置字体大小
plt.rcParams['font.size'] = 12

# 模型和指标
models = ['XGBoost', 'LightGBM', 'KNN', 'Decision Tree', 'Naive Bayes', 'Logistic Regression']
metrics = ['Accuracy', 'Precision', 'Recall', 'F1', 'AUC-ROC', 'AUC-PR']
values = {
    'XGBoost': [0.9964, 0.9938, 0.9848, 0.9893, 0.9998, 0.9991],
    'LightGBM': [0.9939, 0.9853, 0.9777, 0.9815, 0.9987, 0.9826],
    'KNN': [0.9935, 0.9973, 0.9638, 0.9802, 0.9937, 0.9944],
    'Decision Tree': [0.9954, 0.9909, 0.9816, 0.9862, 0.9899, 0.9878],
    'Naive Bayes': [0.9483, 0.9591, 0.7204, 0.8228, 0.9921, 0.9594],
    'Logistic Regression': [0.8139, 0.0373, 0.0047, 0.0084, 0.7679, 0.2969]
}

fig, ax = plt.subplots()
width = 0.15  # 设置柱形图宽度
x = range(len(metrics))

colors = ['#A6B3FF', '#88D8B0', '#FFC947', '#F67280', '#00CED1', '#FEC8D8']  # 设置颜色
# patterns = ['.', 'o', '*', '/', '\\', 'x']  # 设置柱形图填充形状

# p*x为两个指标之间的宽度，i*(width+x)是两个模型之间的宽度
for i, model in enumerate(models):
    ax.bar([p + i*(width) for p in x], values[model], width=width, label=model, color=colors[i]) # hatch=patterns[i]
    # for j, value in enumerate(values[model]):
    #     ax.text(j + i*(width), value + 0.005, f'{value:.3f}', ha='center', fontsize=8)  # 显示柱形上的值

# 调整柱形图位置
ax.set_xticks([p + 2.5*width for p in x])
ax.set_xticklabels(metrics)
ax.set_xlabel('Metrics')
ax.set_ylabel('Values')
ax.legend(frameon=False, bbox_to_anchor=(1, 1))
plt.savefig('BarChart.svg', format='svg', bbox_inches='tight')
plt.show()
