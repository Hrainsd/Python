import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_curve, auc, precision_recall_curve
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import LogisticRegression
import time

# 设置字体
plt.rcParams['font.family'] = 'Times New Roman'
# 设置字体大小
plt.rcParams['font.size'] = 12

# 加载数据
# 请确保文件路径正确
data = pd.read_csv('C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/3.csv')

# 查看数据基本信息
print(data.info())

# 分离特征和标签
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 数据标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 定义评估指标函数
def evaluate_model(y_true, y_pred, y_pred_prob):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)
    fpr, tpr, _ = roc_curve(y_true, y_pred_prob)
    roc_auc = auc(fpr, tpr)
    return accuracy, precision, recall, f1, fpr, tpr, roc_auc

# xgboost
start_time = time.time()
xgb_clf = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
xgb_clf.fit(X_train_scaled, y_train)
xgb_pred = xgb_clf.predict(X_test_scaled)
end_time = time.time()
xgb_total_time = end_time - start_time
xgb_detection_count = len(X_test_scaled)
xgb_time_per_detection = xgb_total_time / xgb_detection_count * 1000  # 转换成毫秒
xgb_pred_prob = xgb_clf.predict_proba(X_test_scaled)[:, 1]
xgb_accuracy, xgb_precision, xgb_recall, xgb_f1, xgb_fpr, xgb_tpr, xgb_roc_auc = evaluate_model(y_test, xgb_pred, xgb_pred_prob)
print("极致梯度提升树评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(xgb_accuracy, xgb_precision, xgb_recall, xgb_f1, xgb_roc_auc, xgb_total_time, xgb_detection_count, xgb_time_per_detection))

# LightGBM
start_time = time.time()
lgb_clf = lgb.LGBMClassifier()
lgb_clf.fit(X_train_scaled, y_train)
lgb_pred = lgb_clf.predict(X_test_scaled)
end_time = time.time()
lgb_total_time = end_time - start_time
lgb_detection_count = len(X_test_scaled)
lgb_time_per_detection = lgb_total_time / lgb_detection_count * 1000
lgb_pred_prob = lgb_clf.predict_proba(X_test_scaled)[:, 1]
lgb_accuracy, lgb_precision, lgb_recall, lgb_f1, lgb_fpr, lgb_tpr, lgb_roc_auc = evaluate_model(y_test, lgb_pred, lgb_pred_prob)
print("LightGBM评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(
    lgb_accuracy, lgb_precision, lgb_recall, lgb_f1, lgb_roc_auc, lgb_total_time, lgb_detection_count, lgb_time_per_detection))

# k最近邻
start_time = time.time()
knn_clf = KNeighborsClassifier()
knn_clf.fit(X_train_scaled, y_train)
knn_pred = knn_clf.predict(X_test_scaled)
end_time = time.time()
knn_total_time = end_time - start_time
knn_detection_count = len(X_test_scaled)
knn_time_per_detection = knn_total_time / knn_detection_count * 1000
knn_pred_prob = knn_clf.predict_proba(X_test_scaled)[:, 1]
knn_accuracy, knn_precision, knn_recall, knn_f1, knn_fpr, knn_tpr, knn_roc_auc = evaluate_model(y_test, knn_pred, knn_pred_prob)
print("K最近邻评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(knn_accuracy, knn_precision, knn_recall, knn_f1, knn_roc_auc, knn_total_time, knn_detection_count, knn_time_per_detection))

# 决策树
start_time = time.time()
dt_clf = DecisionTreeClassifier()
dt_clf.fit(X_train_scaled, y_train)
dt_pred = dt_clf.predict(X_test_scaled)
end_time = time.time()
dt_total_time = end_time - start_time
dt_detection_count = len(X_test_scaled)
dt_time_per_detection = dt_total_time / dt_detection_count * 1000
dt_pred_prob = dt_clf.predict_proba(X_test_scaled)[:, 1]
dt_accuracy, dt_precision, dt_recall, dt_f1, dt_fpr, dt_tpr, dt_roc_auc = evaluate_model(y_test, dt_pred, dt_pred_prob)
print("决策树评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(dt_accuracy, dt_precision, dt_recall, dt_f1, dt_roc_auc, dt_total_time, dt_detection_count, dt_time_per_detection))

# 朴素贝叶斯
start_time = time.time()
gnb_clf = GaussianNB()
gnb_clf.fit(X_train_scaled, y_train)
gnb_pred = gnb_clf.predict(X_test_scaled)
end_time = time.time()
gnb_total_time = end_time - start_time
gnb_detection_count = len(X_test_scaled)
gnb_time_per_detection = gnb_total_time / gnb_detection_count * 1000
gnb_pred_prob = gnb_clf.predict_proba(X_test_scaled)[:, 1]
gnb_accuracy, gnb_precision, gnb_recall, gnb_f1, gnb_fpr, gnb_tpr, gnb_roc_auc = evaluate_model(y_test, gnb_pred, gnb_pred_prob)
print("朴素贝叶斯评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(gnb_accuracy, gnb_precision, gnb_recall, gnb_f1, gnb_roc_auc, gnb_total_time, gnb_detection_count, gnb_time_per_detection))

# 逻辑回归
start_time = time.time()
logreg_clf = LogisticRegression()
logreg_clf.fit(X_train_scaled, y_train)
logreg_pred = logreg_clf.predict(X_test_scaled)
end_time = time.time()
logreg_total_time = end_time - start_time
logreg_detection_count = len(X_test_scaled)
logreg_time_per_detection = logreg_total_time / logreg_detection_count * 1000
logreg_pred_prob = logreg_clf.predict_proba(X_test_scaled)[:, 1]
logreg_accuracy, logreg_precision, logreg_recall, logreg_f1, logreg_fpr, logreg_tpr, logreg_roc_auc = evaluate_model(y_test, logreg_pred, logreg_pred_prob)
print("逻辑回归评估指标：准确率 {:.4f}, 精确率 {:.4f}, 召回率 {:.4f}, F1 {:.4f}, ROC AUC {:.4f}, 总检测耗时 {:.4f}s, 异常检测次数 {}, 检测耗时(每次) {:.4f}ms".format(logreg_accuracy, logreg_precision, logreg_recall, logreg_f1, logreg_roc_auc, logreg_total_time, logreg_detection_count, logreg_time_per_detection))


# 绘制ROC曲线
plt.figure(figsize=(10, 6))
plt.rcParams['font.family'] = 'Times New Roman'

# 绘制xgboost的ROC曲线
plt.plot(xgb_fpr, xgb_tpr, label='XGBoost (AUC = {:.4f})'.format(xgb_roc_auc), color='#8A2BE2', lw=2)

# 绘制LightGBM的ROC曲线
plt.plot(lgb_fpr, lgb_tpr, label='LightGBM (AUC = {:.4f})'.format(lgb_roc_auc), color='#40E0D0', lw=2)

# 绘制KNN的ROC曲线
plt.plot(knn_fpr, knn_tpr, label='KNN (AUC = {:.4f})'.format(knn_roc_auc), color='#20B2AA', lw=2)

# 绘制决策树的ROC曲线
plt.plot(dt_fpr, dt_tpr, label='Decision Tree (AUC = {:.4f})'.format(dt_roc_auc), color='#FF69B4', lw=2)

# 绘制朴素贝叶斯的ROC曲线
plt.plot(gnb_fpr, gnb_tpr, label='GaussianNB (AUC = {:.4f})'.format(gnb_roc_auc), color='#FF4500', lw=2)

# 绘制LR的ROC曲线
plt.plot(logreg_fpr, logreg_tpr, label='Logistic Regression (AUC = {:.4f})'.format(logreg_roc_auc), color='#0066CC', lw=2)

plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic Curve (ROC)')
plt.legend(loc="lower right", frameon = False)
plt.savefig('ROC.svg', format='svg', bbox_inches='tight')
plt.show()


# 绘制PRC曲线
plt.figure(figsize=(10, 6))
plt.rcParams['font.family'] = 'Times New Roman'

# 计算xgboost的PRC曲线
xgb_precision, xgb_recall, _ = precision_recall_curve(y_test, xgb_pred_prob)
xgb_auc = auc(xgb_recall, xgb_precision)
plt.plot(xgb_recall, xgb_precision, label='XGBoost (AUC = {:.4f})'.format(xgb_auc), color='#8A2BE2', lw=2)

# 计算LightGBM的PRC曲线
lgb_precision, lgb_recall, _ = precision_recall_curve(y_test, lgb_pred_prob)
lgb_auc = auc(lgb_recall, lgb_precision)
plt.plot(lgb_recall, lgb_precision, label='LightGBM (AUC = {:.4f})'.format(lgb_auc), color='#40E0D0', lw=2)

# 计算KNN的PRC曲线
knn_precision, knn_recall, _ = precision_recall_curve(y_test, knn_pred_prob)
knn_auc = auc(knn_recall, knn_precision)
plt.plot(knn_recall, knn_precision, label='KNN (AUC = {:.4f})'.format(knn_auc), color='#20B2AA', lw=2)

# 计算决策树的PRC曲线
dt_precision, dt_recall, _ = precision_recall_curve(y_test, dt_pred_prob)
dt_auc = auc(dt_recall, dt_precision)
plt.plot(dt_recall, dt_precision, label='Decision Tree (AUC = {:.4f})'.format(dt_auc), color='#FF69B4', lw=2)

# 计算朴素贝叶斯的PRC曲线
gnb_precision, gnb_recall, _ = precision_recall_curve(y_test, gnb_pred_prob)
gnb_auc = auc(gnb_recall, gnb_precision)
plt.plot(gnb_recall, gnb_precision, label='GaussianNB (AUC = {:.4f})'.format(gnb_auc), color='#FF4500', lw=2)

# 计算LR的PRC曲线
logreg_precision, logreg_recall, _ = precision_recall_curve(y_test, logreg_pred_prob)
logreg_auc = auc(logreg_recall, logreg_precision)
plt.plot(logreg_recall, logreg_precision, label='Logistic Regression (AUC = {:.4f})'.format(logreg_auc), color='#0066CC', lw=2)

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision Recall Curve (PRC)')
plt.legend(loc="lower right", frameon = False)
plt.savefig('PRC.svg', format='svg', bbox_inches='tight')
plt.show()

# 打印PRC AUC
print("XGBoost PRC AUC: {:.4f}".format(xgb_auc))
print("LightGBM PRC AUC: {:.4f}".format(lgb_auc))
print("KNN PRC AUC: {:.4f}".format(knn_auc))
print("Decision Tree PRC AUC: {:.4f}".format(dt_auc))
print("GaussianNB PRC AUC: {:.4f}".format(gnb_auc))
print("Logistic Regression PRC AUC: {:.4f}".format(logreg_auc))

# import pandas as pd
#
# # 读取新数据
# new_data = pd.read_csv('C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/GAN/newdata.csv')
#
# # 获取原始数据的列名，并将其应用到新数据上
# new_data_columns = data.columns.tolist()
#
# # 获取新数据的形状
# num_rows, num_columns = new_data.shape
#
# # 对新数据进行与训练数据相同的预处理步骤，假设scaler是之前已经定义好的
# new_data_scaled = scaler.transform(new_data)
#
# # 使用训练好的模型进行预测，假设xgb_clf是之前已经定义好的模型
# new_data_pred = xgb_clf.predict(new_data_scaled)
# new_data_pred_prob = xgb_clf.predict_proba(new_data_scaled)[:, 1]
#
# # 创建带有预测结果的 DataFrame
# new_data_with_pred = pd.DataFrame(new_data, columns=new_data_columns[:num_columns])
# new_data_with_pred['predicted_label'] = new_data_pred
# new_data_with_pred['predicted_prob'] = new_data_pred_prob
#
# # 保存带有预测结果的新数据到 newdata_result.csv
# new_data_with_pred.to_csv('C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/GAN/newdata_result.csv', index=False)

# 极致梯度提升树评估指标：准确率 0.9998, 精确率 1.0000, 召回率 0.9989, F1 0.9994, ROC AUC 1.0000,PRC AUC: 1.0000
# K最近邻评估指标：准确率 0.9995, 精确率 1.0000, 召回率 0.9967, F1 0.9983, ROC AUC 0.9993,PRC AUC: 0.9994
# 决策树评估指标：准确率 0.9995, 精确率 0.9997, 召回率 0.9975, F1 0.9986, ROC AUC 0.9987,PRC AUC: 0.9988
# 朴素贝叶斯评估指标：准确率 0.9783, 精确率 0.9549, 召回率 0.9115, F1 0.9327, ROC AUC 0.9954,PRC AUC: 0.9823
# 逻辑回归评估指标：准确率 0.8934, 精确率 0.6870, 召回率 0.6469, F1 0.6663, ROC AUC 0.9496,PRC AUC: 0.7034