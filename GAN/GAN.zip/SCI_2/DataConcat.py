import pandas as pd

# 定义文件路径
file_path_1 = r'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/1.csv'
file_path_2 = r'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/2.csv'
output_file_path_1_1 = r'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/1.1.csv'
output_file_path_2_1 = r'C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/2.1.csv'

# 读取1.csv文件并添加Label列，正常数据值全为0
df_1 = pd.read_csv(file_path_1)
df_1['Label'] = 0
df_1.to_csv(output_file_path_1_1, index=False)

# 读取2.csv文件并添加Label列，值全为1，异常数据Label为1
df_2 = pd.read_csv(file_path_2)
df_2['Label'] = 1
df_2.to_csv(output_file_path_2_1, index=False)

print("新列已添加并保存到新的CSV文件中。")


# 读取两个CSV文件
df1 = pd.read_csv(output_file_path_1_1)
df2 = pd.read_csv(output_file_path_2_1)

# 合并两个DataFrame
merged_df = pd.concat([df1, df2])

# 将合并后的DataFrame保存为新的CSV文件
merged_df.to_csv('C:/Users/23991/OneDrive/桌面/Python/venv/shuxuejianmo/shu_xue_jian_mo/SCI_2/3.csv', index=False)
